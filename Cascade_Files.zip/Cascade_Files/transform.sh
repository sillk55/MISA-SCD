#!/bin/bash
# 把W的级联文件改造成SCD程序可读格式
# 新格式要求：每个级联放在一个文件内，间隙团簇数，间隙团簇尺寸+数目，空位团簇数，空位团簇尺寸+数目
# 所以需要读mergedW*txt文件，识别出每个级联，然后对级联进行处理
# 已经确认过，W文件第4行即为级联数目，每个级联严格地用1个空行进行分割
keV=(1 5 10 20 35 50 80 100 150 200 300)
for i in ${keV[@]}; do
	fn=mergedW_"$i"keV.txt
	ncas=`sed -n "4p;5q" $fn|awk '{print $1}'`
	grep "^$" $fn -n | awk -F: '{print $1}'	> LineId
	awk -v v1=$i 'BEGIN{c = 0; d = 0;}
		FILENAME == ARGV[1]{ line[c++] = $1; }
		FILENAME == ARGV[2]{ str[d++] = $0; }
	END{
		for(i = 0; i - c < 0; i++)
		{
			startL = line[i] + 1;
			endL = line[i+1] - 1;
			if(i == c - 1) endL = d;
			
			for(s in itl) delete itl[s];	
			for(s in vac) delete vac[s];	
			nitl = 0;
			nvac = 0;

			for(j = startL; j - endL <= 0; j++)
			{
				if(str[j] ~ "I" || str[j] ~ "V")
				{
					if(str[j] ~ "I")
					{
						split(str[j], tmp);
						gsub("I", "", tmp[4]);
						itl[tmp[4]]++;
					}	
					
					if(str[j] ~ "V")
					{
						split(str[j], tmp);
						gsub("V", "", tmp[4]);
						vac[tmp[4]]++;
					}
				}	
			}
			id = i + 1;
			for(q in itl) nitl++;
			print nitl 	> 	v1"_"id".dat";
			for(q in itl) print q, itl[q]	>  v1"_"id".dat";

			for(q in vac) nvac++;
			print nvac 	> 	v1"_"id".dat";
			for(q in vac) print q, vac[q]	>  v1"_"id".dat";
		}
	}' LineId $fn
done

