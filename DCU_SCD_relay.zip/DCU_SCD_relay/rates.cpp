/* Compute rates and other utilities.
 * 完美融合：初始物理数据 + GPU Phase 4.2 (纯 CPU 控制逻辑，GPU 引擎已搬迁至 RateMatrix)
 */

#include "types.h"
#include "constants.h"
#include "RateMatrix.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define NMAX 1000    
int damage[2][NMAX]; 

#define num_of_PKA_energy 11
extern double PKA_energy[num_of_PKA_energy];
extern int num_of_Cas_per_energy[num_of_PKA_energy];
extern double p_of_PKA_energy[num_of_PKA_energy];
extern struct cascade_def **casdef;

int64 inout_Ndeftotal(int n)
{
  static int64 Ndeftotal = 0;
  Ndeftotal += n;
  return Ndeftotal;
}

void sample_pka_energy(double xi1, double xi2, int *id1, int *id2)
{
  double sump = 0;
  for (int i = 0; i < num_of_PKA_energy; i++)
  {
    if (sump <= xi1 && sump + p_of_PKA_energy[i] > xi1)
    {
      *id1 = i;
      *id2 = (int)(num_of_Cas_per_energy[i] * xi2);
      return;
    }
    else
      sump += p_of_PKA_energy[i];
  }
}

void process_event(struct object_t *my_object, int64 k2, int n2, double adv_time)
{ 
  int64 mono_key = 0, cluster_key = 0;
  int attr[LEVELS], clstr_attr[LEVELS], att[LEVELS] = {0};
  struct object_t *new_object, *other_object, *P_object;

  if (n2 == 0) {
    my_object->number--;
    update(rateMatrix, my_object->key, current_mesh->objects_all);
  } else if ((n2 > 0) && (n2 <= LEVELS)) {
    mono_key = signof(my_object->attributes[n2 - 1]) * ((int64)pow(10.0, (double)EXP10 * (LEVELS - n2))); 
    get_attributes(mono_key, attr);
    
    cluster_key = (int64)signof(my_object->attributes[0]) * (int64)(llabs(my_object->key) - llabs(mono_key));
    if (cluster_key < 0 && cluster_key > -1 * pow(10, (LEVELS - 1) * 3)) cluster_key *= -1; 
    get_attributes(cluster_key, clstr_attr);

    if (find_object_hash(mono_key) == NULL) { 
      double bind_out[LEVELS]; compute_bind_term(attr, bind_out);
      P_object = add_object_hash(mono_key, attr, 1, 3, compute_diff_coeff(attr), bind_out);
      rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = P_object - current_mesh->objects_all;
    } else { 
      new_object = find_object_hash(mono_key);
      new_object->number++;
      update(rateMatrix, new_object->key, current_mesh->objects_all);
    }

    if (find_object_hash(cluster_key) == NULL) {                                    
      int dim = (clstr_attr[0] > 4) ? 1 : 3; 
      double bind_out[LEVELS]; compute_bind_term(clstr_attr, bind_out);
      P_object = add_object_hash(cluster_key, clstr_attr, 1, dim, compute_diff_coeff(clstr_attr), bind_out);
      rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = P_object - current_mesh->objects_all;
    } else { 
      new_object = find_object_hash(cluster_key);
      new_object->number++;
      update(rateMatrix, new_object->key, current_mesh->objects_all);
    }

    my_object->number--;
    update(rateMatrix, my_object->key, current_mesh->objects_all);
  } else if (n2 > LEVELS) {
    other_object = find_object_hash(k2);
    for (int i = 0; i < LEVELS; i++) {
      att[i] = my_object->attributes[i] + other_object->attributes[i];
      if (att[i] > 0.8 * pow(10.0, (double)EXP10)) { printf("Overflow!\n"); exit(1); } 
      cluster_key += labs(att[i]) * ((int64)pow(10.0, (double)EXP10 * (LEVELS - 1 - i)));
    }
    cluster_key *= signof(att[0]);

    if (find_object_hash(cluster_key) == NULL) {                             
      int dim = (att[0] > 4) ? 1 : 3; 
      double bind_out[LEVELS]; compute_bind_term(att, bind_out);
      P_object = add_object_hash(cluster_key, att, 1, dim, compute_diff_coeff(att), bind_out);
      rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = P_object - current_mesh->objects_all;
    } else { 
      new_object = find_object_hash(cluster_key);
      new_object->number++;
      update(rateMatrix, new_object->key, current_mesh->objects_all);
    }

    my_object->number--; other_object->number--;
    update(rateMatrix, my_object->key, current_mesh->objects_all); 
    update(rateMatrix, other_object->key, current_mesh->objects_all);
  }
}

void get_insertion(const int channel)
{
  struct object_t *my_object;
  struct object_t *newObject;
  int attr[LEVELS];
  int i, j;
  int64 e_key = 0;

  const int types = 2; 

  switch (channel)
  {
  case 0: 
    {
      double xi1 = drand48();
      double xi2 = drand48();
      int id1 = 0, id2 = 0;
      sample_pka_energy(xi1, xi2, &id1, &id2);

      for (int i = 0; i < 2; i++)
        for (int j = 0; j < NMAX; j++)
          damage[i][j] = 0;
      
      for (int k = 0; k < casdef[id1][id2].nvdef; k++)
      {
        int vsize = casdef[id1][id2].vsize[k];
        int vnum = casdef[id1][id2].vnum[k];
        if (vsize > 0 && vsize <= NMAX) damage[0][vsize - 1] = vnum; 
      }
      for (int k = 0; k < casdef[id1][id2].nidef; k++)
      {
        int isize = casdef[id1][id2].isize[k];
        int inum = casdef[id1][id2].inum[k];
        if (isize > 0 && isize <= NMAX) damage[1][isize - 1] = inum; 
      }

      for (j = 0; j < types; j++)
      {
        int sign = (j == 0) ? -1 : 1;
        for (i = 0; i < NMAX; i++)
        {
          if (damage[j][i] != 0)
          {
            e_key = (int64)sign * (i + 1) * (pow(10.0, (double)EXP10 * (LEVELS - 1))); 

            if (find_object_hash(e_key) == NULL)
            { 
              get_attributes(e_key, attr);
              int dim = (attr[0] > 4) ? 1 : 3;
              double bind_out[LEVELS];
              compute_bind_term(attr, bind_out);
              newObject = add_object_hash(e_key, attr, damage[j][i], dim, compute_diff_coeff(attr), bind_out); 
              rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = newObject - current_mesh->objects_all;
            }
            else
            { 
              my_object = find_object_hash(e_key);
              my_object->number += damage[j][i];
              update(rateMatrix, e_key, current_mesh->objects_all);
            } 
          } 
        } 
      } 
    }
    break;

  case 1: 
    if (drand48() < 0.0) 
    { 
      e_key = -1 * ((int64)pow(10.0, (double)EXP10 * (LEVELS - 1)) + (int64)pow(10.0, (double)EXP10 * (LEVELS - 2)));
    }
    else
    {
      e_key = (int64)pow(10.0, (double)EXP10 * (LEVELS - 2));
    }

    if (find_object_hash(e_key) == NULL)
    { 
      get_attributes(e_key, attr);
      double bind_out[LEVELS];
      compute_bind_term(attr, bind_out);
      newObject = add_object_hash(e_key, attr, 1, 3, compute_diff_coeff(attr), bind_out); 
      rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = newObject - current_mesh->objects_all;
    }
    else
    { 
      my_object = find_object_hash(e_key);
      my_object->number++;
      update(rateMatrix, e_key, current_mesh->objects_all);
    }
    break;
  }
}