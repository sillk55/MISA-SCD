#include "types.h"
#include "RateMatrix.h"
#include <stdio.h>
#include <stdlib.h>

extern struct mesh_t *current_mesh; 

int key_sort(const void *a, const void *b) {
    const struct object_t *objA = (const struct object_t *)a;
    const struct object_t *objB = (const struct object_t *)b;
    if (objB->key > objA->key) return 1;
    if (objB->key < objA->key) return -1;
    return 0;
}

void sort_objects() {
    if (current_mesh->active_objects_count > 1) {
        qsort(current_mesh->objects_all, current_mesh->active_objects_count, sizeof(struct object_t), key_sort);
    }
}

// 核心修改：接收栈数组，不再释放 binding 内存
struct object_t* add_object_hash(int64         new_object_id,
                                 const int     *new_object_attributes,
                                 int           new_object_number,
                                 unsigned int  new_object_dimensionality,
                                 double        new_object_diff,
                                 const double  *new_object_binding) {
    
    if (current_mesh->active_objects_count >= MAX_SPECIES) {
        fprintf(stderr, "Error: MAX_SPECIES (%d) exceeded in mesh %d!\n", MAX_SPECIES, current_mesh->local_id);
        exit(EXIT_FAILURE);
    }
    
    int idx = current_mesh->active_objects_count;
    struct object_t *P_object = &current_mesh->objects_all[idx];
    
    P_object->key = new_object_id;
    for (int i_level=0; i_level<LEVELS; i_level++) {
        P_object->attributes[i_level] = new_object_attributes[i_level];
        P_object->binding[i_level] = new_object_binding[i_level];
    }
    P_object->number = new_object_number;
    P_object->dimensionality = new_object_dimensionality;
    P_object->diff = new_object_diff;
    
    current_mesh->active_objects_count++;
    return P_object;
}

struct object_t *find_object_hash(int64 object_id) {
    for (int i = 0; i < current_mesh->active_objects_count; i++) {
        if (current_mesh->objects_all[i].key == object_id) {
            return &current_mesh->objects_all[i];
        }
    }
    return NULL;
}

void delete_object_hash(struct object_t *obj_to_delete) {
    int index = obj_to_delete - current_mesh->objects_all; 
    if (index >= 0 && index < current_mesh->active_objects_count) {
        current_mesh->active_objects_count--;
        if (index != current_mesh->active_objects_count) {
            struct object_t *moving_obj = &current_mesh->objects_all[current_mesh->active_objects_count];
            current_mesh->objects_all[index] = *moving_obj;
            update_matrix_object_index(current_mesh->matrix, moving_obj->key, index);
        }
    }
}