/**
 * Stochastic cluster dynamics implementation with Gillespie algorithm.
 * * MPI VERSION: Phase 4.3 
 * * PROFILER VERSION: Added precision timers to isolate PCIe bottleneck
 **/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "types.h"
#include "constants.h"
#include "RateMatrix.h"

#ifdef __cplusplus
#define typeof decltype
#endif

extern "C" {
#include "uthash.h"
}

#include <mpi.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

double input_total_volume = 7.8e-14;
int input_nx_local = 5;
int input_ny_local = 5;
int input_nz_local = 5;
double input_target_time = 0.0;

struct mesh_t *local_meshes = NULL;
struct mesh_t *d_local_meshes = NULL; 
struct mesh_t *current_mesh = NULL;  

struct cascade_def **casdef = NULL;
#define num_of_PKA_energy 11
double PKA_energy[num_of_PKA_energy];
int num_of_Cas_per_energy[num_of_PKA_energy];
double p_of_PKA_energy[num_of_PKA_energy];

struct RateMatrix *rateMatrix = NULL;

double local_volume;
double mesh_Lx, mesh_Ly, mesh_Lz;
double mesh_volume;

int64 i_step = 0; 

// ==========================================
// >>> 性能探针全局累加器 <<<
// ==========================================
double prof_h2d_time = 0.0;
double prof_kernel_time = 0.0;
double prof_d2h_time = 0.0;
double prof_mpi_cpu_time = 0.0;

struct PackParticle {
    int tgt_i, tgt_j, tgt_k;           
    int64 key;                         
    int attributes[LEVELS];            
    int number;                        
    unsigned int dimensionality;       
    double diff;                       
    double binding[LEVELS];            
};

struct sector_t local_sectors[8];
int num_local_meshes = 0;
int num_total_meshes = 0;

struct ClusterStat {
    int attrs[LEVELS];     
    long long total_count; 
    UT_hash_handle hh; 
};

struct RateMatrix *h_matrices = NULL;
struct RateMatrix *d_matrices = NULL;

void sync_meshes_H2D(int total_meshes) {
    double t_start = MPI_Wtime();
    for(int m = 0; m < total_meshes; m++) local_meshes[m].matrix = &d_matrices[m];
    hipMemcpy(d_local_meshes, local_meshes, total_meshes * sizeof(struct mesh_t), hipMemcpyHostToDevice);
    for(int m = 0; m < total_meshes; m++) local_meshes[m].matrix = &h_matrices[m];
    hipMemcpy(d_matrices, h_matrices, total_meshes * sizeof(struct RateMatrix), hipMemcpyHostToDevice);
    prof_h2d_time += (MPI_Wtime() - t_start);
}

void sync_meshes_D2H(int total_meshes) {
    double t_start = MPI_Wtime();
    hipMemcpy(local_meshes, d_local_meshes, total_meshes * sizeof(struct mesh_t), hipMemcpyDeviceToHost);
    for(int m = 0; m < total_meshes; m++) local_meshes[m].matrix = &h_matrices[m];
    hipMemcpy(h_matrices, d_matrices, total_meshes * sizeof(struct RateMatrix), hipMemcpyDeviceToHost);
    prof_d2h_time += (MPI_Wtime() - t_start);
}

void init_simulation_params(int my_rank) {
    if (my_rank == 0) {
        FILE *fp = fopen("SLSCD.in", "r");
        if (fp == NULL) {
            printf("\n[Warning] Cannot find 'SLSCD.in'. Using hardcoded default values.\n");
        } else {
            char line[256]; char key[128]; double val;
            while (fgets(line, sizeof(line), fp)) {
                if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;
                if (sscanf(line, "%s %lf", key, &val) == 2) {
                    if (strcmp(key, "input_total_volume") == 0) input_total_volume = val;
                    else if (strcmp(key, "NX_LOCAL") == 0) input_nx_local = (int)val;
                    else if (strcmp(key, "NY_LOCAL") == 0) input_ny_local = (int)val;
                    else if (strcmp(key, "NZ_LOCAL") == 0) input_nz_local = (int)val;
                    else if (strcmp(key, "TARGET_TIME") == 0) input_target_time = val;
                }
            }
            fclose(fp);
            printf("\n[Info] Successfully loaded parameters from 'SLSCD.in'.\n");
        }
    }
    MPI_Bcast(&input_total_volume, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&input_nx_local, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&input_ny_local, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&input_nz_local, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&input_target_time, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
}

int stat_sort(const struct ClusterStat *a, const struct ClusterStat *b) {
    for(int k=0; k<LEVELS; k++) {
        if (a->attrs[k] != b->attrs[k]) return a->attrs[k] - b->attrs[k];
    }
    return 0;
}

void setup_pka_on_gpu(double **d_PKA_energy, double **d_p_of_PKA_energy, int **d_num_of_Cas_per_energy, struct cascade_def ***d_casdef) {
#if defined(PKA)
    hipMalloc(d_PKA_energy, num_of_PKA_energy * sizeof(double));
    hipMemcpy(*d_PKA_energy, PKA_energy, num_of_PKA_energy * sizeof(double), hipMemcpyHostToDevice);
    hipMalloc(d_p_of_PKA_energy, num_of_PKA_energy * sizeof(double));
    hipMemcpy(*d_p_of_PKA_energy, p_of_PKA_energy, num_of_PKA_energy * sizeof(double), hipMemcpyHostToDevice);
    hipMalloc(d_num_of_Cas_per_energy, num_of_PKA_energy * sizeof(int));
    hipMemcpy(*d_num_of_Cas_per_energy, num_of_Cas_per_energy, num_of_PKA_energy * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(d_casdef, num_of_PKA_energy * sizeof(struct cascade_def *));
    
    struct cascade_def **h_casdef_array = (struct cascade_def **)malloc(num_of_PKA_energy * sizeof(struct cascade_def *));
    for (int i = 0; i < num_of_PKA_energy; i++) {
        int n_cas = num_of_Cas_per_energy[i];
        struct cascade_def *d_cas_list;
        hipMalloc(&d_cas_list, n_cas * sizeof(struct cascade_def));
        h_casdef_array[i] = d_cas_list;

        struct cascade_def *h_temp = (struct cascade_def *)malloc(n_cas * sizeof(struct cascade_def));
        for (int j = 0; j < n_cas; j++) {
            h_temp[j] = casdef[i][j];
            if (h_temp[j].nidef > 0) {
                hipMalloc(&(h_temp[j].isize), h_temp[j].nidef * sizeof(int)); hipMemcpy(h_temp[j].isize, casdef[i][j].isize, h_temp[j].nidef * sizeof(int), hipMemcpyHostToDevice);
                hipMalloc(&(h_temp[j].inum), h_temp[j].nidef * sizeof(int));  hipMemcpy(h_temp[j].inum, casdef[i][j].inum, h_temp[j].nidef * sizeof(int), hipMemcpyHostToDevice);
            }
            if (h_temp[j].nvdef > 0) {
                hipMalloc(&(h_temp[j].vsize), h_temp[j].nvdef * sizeof(int)); hipMemcpy(h_temp[j].vsize, casdef[i][j].vsize, h_temp[j].nvdef * sizeof(int), hipMemcpyHostToDevice);
                hipMalloc(&(h_temp[j].vnum), h_temp[j].nvdef * sizeof(int));  hipMemcpy(h_temp[j].vnum, casdef[i][j].vnum, h_temp[j].nvdef * sizeof(int), hipMemcpyHostToDevice);
            }
        }
        hipMemcpy(d_cas_list, h_temp, n_cas * sizeof(struct cascade_def), hipMemcpyHostToDevice);
        free(h_temp);
    }
    hipMemcpy(*d_casdef, h_casdef_array, num_of_PKA_energy * sizeof(struct cascade_def *), hipMemcpyHostToDevice);
    free(h_casdef_array);
#endif
}

int main(int argc, char *argv[])
{
    int my_rank, num_tasks;
    MPI_Comm comm;              
    int dims[3] = {0, 0, 0};    
    int periods[3] = {1, 1, 1}; 
    int my_coords[3];           
    int neighbors[6];           

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &num_tasks);

    init_simulation_params(my_rank);

    double wall_start_time = MPI_Wtime();
    double target_time = 0.0;
    
    if (argc > 1) target_time = atof(argv[1]);
    else if (input_target_time > 0.0) target_time = input_target_time;
    else target_time = TOTAL_DPA * 1.0 / DPA_RATE;

    if (my_rank == 0) {
        printf("\n================ [SIMULATION SETTINGS] ================\n");
        printf("  => Target Time: %.4e [s]\n", target_time);
        printf("=======================================================\n\n");
    }

    MPI_Dims_create(num_tasks, 3, dims);
    MPI_Cart_create(MPI_COMM_WORLD, 3, dims, periods, 1, &comm);
    MPI_Comm_rank(comm, &my_rank); 
    MPI_Cart_coords(comm, my_rank, 3, my_coords);
    MPI_Cart_shift(comm, 0, 1, &neighbors[0], &neighbors[1]);
    MPI_Cart_shift(comm, 1, 1, &neighbors[2], &neighbors[3]);
    MPI_Cart_shift(comm, 2, 1, &neighbors[4], &neighbors[5]);

    double global_L = pow(input_total_volume, 1.0/3.0); 
    double proc_Lx = global_L / (double)dims[0];
    double proc_Ly = global_L / (double)dims[1];
    double proc_Lz = global_L / (double)dims[2];

    double my_xmin = my_coords[0] * proc_Lx;
    double my_ymin = my_coords[1] * proc_Ly;
    double my_zmin = my_coords[2] * proc_Lz;

    local_volume = proc_Lx * proc_Ly * proc_Lz;

    int nx_local = input_nx_local, ny_local = input_ny_local, nz_local = input_nz_local;
    int nx_pad = nx_local + 2, ny_pad = ny_local + 2, nz_pad = nz_local + 2;

    num_local_meshes = nx_local * ny_local * nz_local; 
    num_total_meshes = nx_pad * ny_pad * nz_pad;       
    local_meshes = (struct mesh_t *)malloc(num_total_meshes * sizeof(struct mesh_t));
    
    mesh_Lx = proc_Lx / nx_local;
    mesh_Ly = proc_Ly / ny_local;
    mesh_Lz = proc_Lz / nz_local;
    mesh_volume = mesh_Lx * mesh_Ly * mesh_Lz;

    #define MESH_ID(i, j, k) ((k) * ny_pad * nx_pad + (j) * nx_pad + (i))

    for (int k = 0; k < nz_pad; k++) {
        for (int j = 0; j < ny_pad; j++) {
            for (int i = 0; i < nx_pad; i++) {
                int id = MESH_ID(i, j, k);
                local_meshes[id].local_id = id;
                local_meshes[id].volume = mesh_volume;
                local_meshes[id].lock = 0; 
                
                if (i == 0 || i == nx_pad - 1 || j == 0 || j == ny_pad - 1 || k == 0 || k == nz_pad - 1) {
                    local_meshes[id].is_ghost = 1;
                } else {
                    local_meshes[id].is_ghost = 0;
                    if (i == 1 || i == nx_local || j == 1 || j == ny_local || k == 1 || k == nz_local) {
                        local_meshes[id].is_shell = 1; 
                    } else {
                        local_meshes[id].is_shell = 0; 
                    }
                }
                
                if (!local_meshes[id].is_ghost) {
                    local_meshes[id].neighbor_ids[0] = MESH_ID(i-1, j, k); local_meshes[id].neighbor_ids[1] = MESH_ID(i+1, j, k); 
                    local_meshes[id].neighbor_ids[2] = MESH_ID(i, j-1, k); local_meshes[id].neighbor_ids[3] = MESH_ID(i, j+1, k); 
                    local_meshes[id].neighbor_ids[4] = MESH_ID(i, j, k-1); local_meshes[id].neighbor_ids[5] = MESH_ID(i, j, k+1); 
                }
                local_meshes[id].active_objects_count = 0;
            }
        }
    }

    for (int s = 0; s < 8; s++) {
        local_sectors[s].sector_id = s;
        local_sectors[s].num_meshes = 0;
        local_sectors[s].mesh_ids = (int *)malloc(num_local_meshes * sizeof(int));
    }

    for (int k = 1; k <= nz_local; k++) {
        for (int j = 1; j <= ny_local; j++) {
            for (int i = 1; i <= nx_local; i++) {
                int id = MESH_ID(i, j, k);
                int sector_id = ((k-1) % 2) * 4 + ((j-1) % 2) * 2 + ((i-1) % 2);
                local_sectors[sector_id].mesh_ids[local_sectors[sector_id].num_meshes++] = id;
            }
        }
    }

    long int my_seed = 1715161000u + (long int)my_rank * 1000; 
    srand48(my_seed);

    FILE *fp = NULL, *fs = NULL, *ft = NULL, *f_tc = NULL;
    clock_t start, end; 
    double elapsed;

    if (my_rank == 0) {
        #if defined(_WIN32)
            _mkdir("out");
        #else
            mkdir("out", 0777); 
        #endif
        fp = fopen("out/time.out", "w"); fs = fopen("out/sinks.out", "w"); ft = fopen("out/timeconsumption.out", "w"); f_tc = fopen("out/tc.txt", "w");
        if (!fp || !fs || !ft || !f_tc) MPI_Abort(MPI_COMM_WORLD, 1);
        printf("\nStarting MEGA-KERNEL GPU Simulation...\n\n");
    }

#if defined(PKA) 
    const char CAS_DEF_INFO[] = "Cascade_Files/cascade_info.dat";
    if (my_rank == 0) {
        FILE *fc = fopen(CAS_DEF_INFO, "r");
        if (!fc) MPI_Abort(MPI_COMM_WORLD, 1);
        char buff[400]; fscanf(fc, "%s %s %s", buff, buff, buff);
        for (int i = 0; i < num_of_PKA_energy; i++) {
            fscanf(fc, "%s", buff); PKA_energy[i] = atof(buff); fscanf(fc, "%s", buff); num_of_Cas_per_energy[i] = atoi(buff); fscanf(fc, "%s", buff); p_of_PKA_energy[i] = atof(buff);
        }
        fclose(fc);
    }
    MPI_Bcast(PKA_energy, num_of_PKA_energy, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(num_of_Cas_per_energy, num_of_PKA_energy, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(p_of_PKA_energy, num_of_PKA_energy, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    casdef = (struct cascade_def **)malloc(sizeof(struct cascade_def *) * num_of_PKA_energy);
    for (int i = 0; i < num_of_PKA_energy; i++) {
        casdef[i] = (struct cascade_def *)malloc(sizeof(struct cascade_def) * num_of_Cas_per_energy[i]);
        for (int j = 0; j < num_of_Cas_per_energy[i]; j++) {
            casdef[i][j].cascade_energy = PKA_energy[i];
            casdef[i][j].cascade_id = j + 1;
            
            if (my_rank == 0) {
                char fn[400], b[400]; sprintf(fn, "Cascade_Files/%d_%d.dat", (int)(PKA_energy[i]), j + 1); 
                FILE *fcas = fopen(fn, "r");
                fscanf(fcas, "%s", b); casdef[i][j].nidef = atoi(b);
                casdef[i][j].isize = (int *)malloc(sizeof(int)*casdef[i][j].nidef); casdef[i][j].inum  = (int *)malloc(sizeof(int)*casdef[i][j].nidef);
                for(int k=0; k<casdef[i][j].nidef; k++) { fscanf(fcas,"%s",b); casdef[i][j].isize[k]=atoi(b); fscanf(fcas,"%s",b); casdef[i][j].inum[k]=atoi(b); }
                
                fscanf(fcas, "%s", b); casdef[i][j].nvdef = atoi(b);
                casdef[i][j].vsize = (int *)malloc(sizeof(int)*casdef[i][j].nvdef); casdef[i][j].vnum  = (int *)malloc(sizeof(int)*casdef[i][j].nvdef);
                for(int k=0; k<casdef[i][j].nvdef; k++) { fscanf(fcas,"%s",b); casdef[i][j].vsize[k]=atoi(b); fscanf(fcas,"%s",b); casdef[i][j].vnum[k]=atoi(b); }
                fclose(fcas);
            }
            MPI_Bcast(&casdef[i][j].nidef, 1, MPI_INT, 0, MPI_COMM_WORLD); MPI_Bcast(&casdef[i][j].nvdef, 1, MPI_INT, 0, MPI_COMM_WORLD);
            
            if (my_rank != 0) {
                casdef[i][j].isize = (int *)malloc(sizeof(int)*casdef[i][j].nidef); casdef[i][j].inum  = (int *)malloc(sizeof(int)*casdef[i][j].nidef);
                casdef[i][j].vsize = (int *)malloc(sizeof(int)*casdef[i][j].nvdef); casdef[i][j].vnum  = (int *)malloc(sizeof(int)*casdef[i][j].nvdef);
            }
            if (casdef[i][j].nidef > 0) { MPI_Bcast(casdef[i][j].isize, casdef[i][j].nidef, MPI_INT, 0, MPI_COMM_WORLD); MPI_Bcast(casdef[i][j].inum,  casdef[i][j].nidef, MPI_INT, 0, MPI_COMM_WORLD); }
            if (casdef[i][j].nvdef > 0) { MPI_Bcast(casdef[i][j].vsize, casdef[i][j].nvdef, MPI_INT, 0, MPI_COMM_WORLD); MPI_Bcast(casdef[i][j].vnum,  casdef[i][j].nvdef, MPI_INT, 0, MPI_COMM_WORLD); }
        }
    }
    MPI_Barrier(MPI_COMM_WORLD); 
#endif

    int num_devices = 0;
    hipGetDeviceCount(&num_devices);
    if (num_devices == 0) MPI_Abort(MPI_COMM_WORLD, 1);
    hipSetDevice(my_rank % num_devices);

    hipMalloc((void**)&d_local_meshes, num_total_meshes * sizeof(struct mesh_t));
    
    h_matrices = (struct RateMatrix *)malloc(num_total_meshes * sizeof(struct RateMatrix));
    hipMalloc((void**)&d_matrices, num_total_meshes * sizeof(struct RateMatrix));

    int64 object = (int64)1; 
    int number_per_mesh = local_meshes[0].volume * DENSITY * 0.10; 
    
    for (int m = 0; m < num_total_meshes; m++) {
        struct RateMatrix *temp = initialization(mesh_volume, local_volume, mesh_Lx, mesh_Ly, mesh_Lz); 
        h_matrices[m] = *temp;  
        free(temp);
        local_meshes[m].matrix = &h_matrices[m]; 

        if (local_meshes[m].is_ghost) continue; 
        
        current_mesh = &local_meshes[m];
        int attr[LEVELS]; double bind_out[LEVELS];
        get_attributes(object, attr); compute_bind_term(attr, bind_out);
        int dimensionality = (attr[0] > 4) ? 1 : 3; 
        add_object_hash(object, attr, number_per_mesh, dimensionality, compute_diff_coeff(attr), bind_out);
    }
    current_mesh = NULL;
    
    double *d_max_rates = NULL; hipMalloc((void**)&d_max_rates, num_total_meshes * sizeof(double));
    double *h_max_rates = (double*)malloc(num_total_meshes * sizeof(double));

    double *d_PKA_energy = NULL, *d_p_of_PKA_energy = NULL; int *d_num_of_Cas_per_energy = NULL; struct cascade_def **d_casdef = NULL;
    setup_pka_on_gpu(&d_PKA_energy, &d_p_of_PKA_energy, &d_num_of_Cas_per_energy, &d_casdef);

    int *d_mesh_ids = NULL; hipMalloc((void**)&d_mesh_ids, num_total_meshes * sizeof(int));
    int *h_mesh_ids = (int*)malloc(num_total_meshes * sizeof(int));

    start = clock();
    double global_time = 0.0; 
    double tau_kmc = 0.0;    

    sync_meshes_H2D(num_total_meshes);

    while (global_time <= target_time)
    {
        double t_kernel_start, t_kernel_end;
        double t_mpi_start, t_mpi_end;
        
        int threads = 256;
        // int max_rate_blocks = (num_total_meshes + threads - 1) / threads;
        int max_rate_blocks = num_total_meshes;

        t_kernel_start = MPI_Wtime();
        calc_max_rate_kernel<<<max_rate_blocks, threads>>>(d_local_meshes, num_total_meshes, global_time, d_max_rates);
        hipDeviceSynchronize();
        prof_kernel_time += (MPI_Wtime() - t_kernel_start);

        double t_h2d_tmp = MPI_Wtime();
        hipMemcpy(h_max_rates, d_max_rates, num_total_meshes * sizeof(double), hipMemcpyDeviceToHost);
        prof_d2h_time += (MPI_Wtime() - t_h2d_tmp);

        double my_max_rate = 0.0, max_rate_network = 0.0;
        for (int m = 0; m < num_total_meshes; m++) { if (h_max_rates[m] > my_max_rate) my_max_rate = h_max_rates[m]; }
        MPI_Allreduce(&my_max_rate, &max_rate_network, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
        if (max_rate_network > 0) tau_kmc = 5.0 / max_rate_network; else tau_kmc = 1.0e-3;

        // ================= SHELL COMPUTATION (GPU MEGA-KERNEL) =================
        t_kernel_start = MPI_Wtime();
        for (int s = 0; s < 8; s++) {
            int active_count = 0;
            for (int mi = 0; mi < local_sectors[s].num_meshes; mi++) {
                int m = local_sectors[s].mesh_ids[mi];
                if (local_meshes[m].is_shell == 1 && !local_meshes[m].is_ghost) h_mesh_ids[active_count++] = m;
            }
            if (active_count > 0) {
                hipMemcpy(d_mesh_ids, h_mesh_ids, active_count * sizeof(int), hipMemcpyHostToDevice);
                unsigned int cur_seed = (unsigned int)(drand48() * 1000000) + s;
                // int blocks = (active_count + threads - 1) / threads;
                int blocks = active_count;
                kmc_evolution_kernel<<<blocks, threads>>>(
                    d_local_meshes, d_mesh_ids, active_count, global_time, tau_kmc, cur_seed,
                    d_PKA_energy, d_p_of_PKA_energy, d_num_of_Cas_per_energy, d_casdef
                );
                hipDeviceSynchronize();
            }
        } 
        prof_kernel_time += (MPI_Wtime() - t_kernel_start);

        // ================= MPI COMMUNICATION =================
        sync_meshes_D2H(num_total_meshes);

        t_mpi_start = MPI_Wtime();
        int send_counts[6] = {0}, recv_counts[6] = {0};
        struct PackParticle *send_bufs[6] = {NULL}, *recv_bufs[6] = {NULL};
        MPI_Request data_send_reqs[6], data_recv_reqs[6];
        int active_send_reqs = 0, active_recv_reqs = 0;

        for (int dir = 0; dir < 6; dir++) {
            int send_to = neighbors[dir];
            int recv_from = neighbors[dir ^ 1]; 
            
            int i_min = 0, i_max = 0, j_min = 0, j_max = 0, k_min = 0, k_max = 0;
            if (dir == 0)      { i_min = i_max = 0;            j_min = 1; j_max = ny_local; k_min = 1; k_max = nz_local; }
            else if (dir == 1) { i_min = i_max = nx_local + 1; j_min = 1; j_max = ny_local; k_min = 1; k_max = nz_local; }
            else if (dir == 2) { i_min = 1; i_max = nx_local; j_min = j_max = 0;            k_min = 1; k_max = nz_local; }
            else if (dir == 3) { i_min = 1; i_max = nx_local; j_min = j_max = ny_local + 1; k_min = 1; k_max = nz_local; }
            else if (dir == 4) { i_min = 1; i_max = nx_local; j_min = 1; j_max = ny_local; k_min = k_max = 0; }
            else if (dir == 5) { i_min = 1; i_max = nx_local; j_min = 1; j_max = ny_local; k_min = k_max = nz_local + 1; }

            for(int k=k_min; k<=k_max; k++) {
                for(int j=j_min; j<=j_max; j++) {
                    for(int i=i_min; i<=i_max; i++) {
                        int id = MESH_ID(i, j, k);
                        send_counts[dir] += local_meshes[id].active_objects_count;
                    }
                }
            }

            MPI_Sendrecv(&send_counts[dir], 1, MPI_INT, send_to, 0, &recv_counts[dir], 1, MPI_INT, recv_from, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            if (recv_counts[dir] > 0) {
                recv_bufs[dir] = (struct PackParticle *)malloc(recv_counts[dir] * sizeof(struct PackParticle));
                MPI_Irecv(recv_bufs[dir], recv_counts[dir] * sizeof(struct PackParticle), MPI_BYTE, recv_from, 1, MPI_COMM_WORLD, &data_recv_reqs[active_recv_reqs++]);
            }

            if (send_counts[dir] > 0) {
                send_bufs[dir] = (struct PackParticle *)malloc(send_counts[dir] * sizeof(struct PackParticle));
                int idx = 0;
                for(int k=k_min; k<=k_max; k++) {
                    for(int j=j_min; j<=j_max; j++) {
                        for(int i=i_min; i<=i_max; i++) {
                            int id = MESH_ID(i, j, k);
                            for (int p_idx = 0; p_idx < local_meshes[id].active_objects_count; p_idx++) {
                                struct object_t *g_obj = &local_meshes[id].objects_all[p_idx];
                                if (dir == 0)      { send_bufs[dir][idx].tgt_i = nx_local; send_bufs[dir][idx].tgt_j = j; send_bufs[dir][idx].tgt_k = k; }
                                else if (dir == 1) { send_bufs[dir][idx].tgt_i = 1;        send_bufs[dir][idx].tgt_j = j; send_bufs[dir][idx].tgt_k = k; }
                                else if (dir == 2) { send_bufs[dir][idx].tgt_i = i;        send_bufs[dir][idx].tgt_j = ny_local; send_bufs[dir][idx].tgt_k = k; }
                                else if (dir == 3) { send_bufs[dir][idx].tgt_i = i;        send_bufs[dir][idx].tgt_j = 1;        send_bufs[dir][idx].tgt_k = k; }
                                else if (dir == 4) { send_bufs[dir][idx].tgt_i = i;        send_bufs[dir][idx].tgt_j = j;        send_bufs[dir][idx].tgt_k = nz_local; }
                                else if (dir == 5) { send_bufs[dir][idx].tgt_i = i;        send_bufs[dir][idx].tgt_j = j;        send_bufs[dir][idx].tgt_k = 1; }
                                
                                send_bufs[dir][idx].key = g_obj->key; send_bufs[dir][idx].number = g_obj->number; send_bufs[dir][idx].dimensionality = g_obj->dimensionality; send_bufs[dir][idx].diff = g_obj->diff;
                                for(int lvl=0; lvl<LEVELS; ++lvl) { send_bufs[dir][idx].attributes[lvl] = g_obj->attributes[lvl]; send_bufs[dir][idx].binding[lvl] = g_obj->binding[lvl]; }
                                idx++;
                            }
                            local_meshes[id].active_objects_count = 0; 
                        }
                    }
                }
                MPI_Isend(send_bufs[dir], send_counts[dir] * sizeof(struct PackParticle), MPI_BYTE, send_to, 1, MPI_COMM_WORLD, &data_send_reqs[active_send_reqs++]);
            }
        }
        prof_mpi_cpu_time += (MPI_Wtime() - t_mpi_start);

        sync_meshes_H2D(num_total_meshes);
        
        // ================= CORE COMPUTATION (GPU MEGA-KERNEL) =================
        t_kernel_start = MPI_Wtime();
        int active_core_count = 0;
        for (int m = 0; m < num_total_meshes; m++) {
            if (local_meshes[m].is_shell == 0 && !local_meshes[m].is_ghost) h_mesh_ids[active_core_count++] = m;
        }
        
        if (active_core_count > 0) {
            hipMemcpy(d_mesh_ids, h_mesh_ids, active_core_count * sizeof(int), hipMemcpyHostToDevice);
            unsigned int cur_seed = (unsigned int)(drand48() * 1000000) + 10;
            // int blocks = (active_core_count + threads - 1) / threads;
            int blocks = active_core_count;
            kmc_evolution_kernel<<<blocks, threads>>>(
                d_local_meshes, d_mesh_ids, active_core_count, global_time, tau_kmc, cur_seed,
                d_PKA_energy, d_p_of_PKA_energy, d_num_of_Cas_per_energy, d_casdef
            );
            hipDeviceSynchronize();
        }
        prof_kernel_time += (MPI_Wtime() - t_kernel_start);

        t_mpi_start = MPI_Wtime();
        if (active_recv_reqs > 0) MPI_Waitall(active_recv_reqs, data_recv_reqs, MPI_STATUSES_IGNORE);
        if (active_send_reqs > 0) MPI_Waitall(active_send_reqs, data_send_reqs, MPI_STATUSES_IGNORE);
        prof_mpi_cpu_time += (MPI_Wtime() - t_mpi_start);

        sync_meshes_D2H(num_total_meshes);

        t_mpi_start = MPI_Wtime();
        for (int dir = 0; dir < 6; dir++) {
            if (recv_counts[dir] > 0) {
                for(int p=0; p<recv_counts[dir]; p++) {
                    int target_id = MESH_ID(recv_bufs[dir][p].tgt_i, recv_bufs[dir][p].tgt_j, recv_bufs[dir][p].tgt_k);
                    current_mesh = &local_meshes[target_id];
                    rateMatrix = local_meshes[target_id].matrix;
                    int64 j_key = recv_bufs[dir][p].key;
                    
                    struct object_t *t_obj = find_object_hash(j_key);
                    if (t_obj == NULL) {
                        int j_attrs[LEVELS]; double j_bind[LEVELS];
                        for(int lvl=0; lvl<LEVELS; ++lvl) { j_attrs[lvl] = recv_bufs[dir][p].attributes[lvl]; j_bind[lvl] = recv_bufs[dir][p].binding[lvl]; }
                        t_obj = add_object_hash(j_key, j_attrs, recv_bufs[dir][p].number, recv_bufs[dir][p].dimensionality, recv_bufs[dir][p].diff, j_bind);
                        if (rateMatrix != NULL) rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = t_obj - current_mesh->objects_all;
                    } else {
                        t_obj->number += recv_bufs[dir][p].number;
                        if (rateMatrix != NULL) update(rateMatrix, j_key, current_mesh->objects_all);
                    }
                }
                free(recv_bufs[dir]);
            }
            if (send_counts[dir] > 0) free(send_bufs[dir]);
        }
        prof_mpi_cpu_time += (MPI_Wtime() - t_mpi_start);
        
        sync_meshes_H2D(num_total_meshes);
        
        MPI_Barrier(MPI_COMM_WORLD);
        global_time += tau_kmc;
        
        // ================= MACRO STATS (Every 200 Steps) =================
        if (i_step % 200 == 0) 
        {
            if (my_rank == 0) {
                double progress_percent = (global_time / target_time) * 100.0;
                double current_wall_time = MPI_Wtime();
                double elapsed_sec = current_wall_time - wall_start_time;
                if (progress_percent > 100.0) progress_percent = 100.0;
                printf("\n  => Time:  %.4e / %.4e [s]\n", global_time, target_time);
                printf("  => Wall Time: %.2f [s] (%.2f mins)\n", elapsed_sec, elapsed_sec / 60.0);
                printf("  => Done:  %6.2f %%\n", progress_percent);
                
                // 打印性能探针面板
                printf("  [Performance Profiler]\n");
                printf("    - H2D Transfer : %8.4f s\n", prof_h2d_time);
                printf("    - GPU Kernel   : %8.4f s  <--- 核心算力区域\n", prof_kernel_time);
                printf("    - D2H Transfer : %8.4f s\n", prof_d2h_time);
                printf("    - MPI+CPU Pack : %8.4f s\n", prof_mpi_cpu_time);
            }
            
            // 重置探针累加器，以便观察下 200 步的变化
            prof_h2d_time = 0.0;
            prof_kernel_time = 0.0;
            prof_d2h_time = 0.0;
            prof_mpi_cpu_time = 0.0;
            
            int sia = 0, v = 0, siac = 0, vc = 0, vhe = 0, siahe = 0;
            int nis = 0, nvs = 0, nhes = 0; 
            int local_cluster_types = 0;
            
            for (int m = 0; m < num_total_meshes; m++) {
                if (local_meshes[m].is_ghost) continue; 
                current_mesh = &local_meshes[m];
                rateMatrix = local_meshes[m].matrix;
                
                for (int i = 0; i < current_mesh->active_objects_count; ) {
                    struct object_t *P_object = &current_mesh->objects_all[i];
                    int check_zero = 0;
                    for (int k = 0; k < LEVELS; k++) check_zero |= P_object->attributes[k];
                    
                    if ((!check_zero) || (P_object->number == 0)) {
                        deleteLine(rateMatrix, P_object->key, current_mesh->objects_all);
                        delete_object_hash(P_object);
                    } else {
                        if (P_object->attributes[0] > 0) {
                            if (P_object->attributes[0] == 1) sia += P_object->number; else siac += P_object->number; 
                        } else if (P_object->attributes[0] < 0) {
                            if (P_object->attributes[0] == -1) v += P_object->number; else vc += P_object->number; 
                        }
                        local_cluster_types++; 
                        i++;
                    }
                }
            }
            
            sync_meshes_H2D(num_total_meshes);
            
            int ints_per_cluster = LEVELS + 1; int *send_buf = NULL;
            if (local_cluster_types > 0) {
                send_buf = (int *)malloc(local_cluster_types * ints_per_cluster * sizeof(int));
                int idx = 0;
                for (int m = 0; m < num_total_meshes; m++) {
                    if (local_meshes[m].is_ghost) continue; 
                    current_mesh = &local_meshes[m];
                    for (int i = 0; i < current_mesh->active_objects_count; i++) {
                        struct object_t *P_object = &current_mesh->objects_all[i];
                        for (int k = 0; k < LEVELS; k++) send_buf[idx++] = P_object->attributes[k]; 
                        send_buf[idx++] = P_object->number;            
                    }
                }
            }

            int send_count = local_cluster_types * ints_per_cluster;
            int *recv_counts = NULL, *displs = NULL;
            if (my_rank == 0) { recv_counts = (int *)malloc(num_tasks * sizeof(int)); displs = (int *)malloc(num_tasks * sizeof(int)); }
            
            MPI_Gather(&send_count, 1, MPI_INT, recv_counts, 1, MPI_INT, 0, MPI_COMM_WORLD);
            
            int *recv_buf = NULL, total_ints = 0;
            if (my_rank == 0) {
                for (int p = 0; p < num_tasks; p++) { displs[p] = total_ints; total_ints += recv_counts[p]; }
                if (total_ints > 0) recv_buf = (int *)malloc(total_ints * sizeof(int));
            }
            
            MPI_Gatherv(send_buf, send_count, MPI_INT, recv_buf, recv_counts, displs, MPI_INT, 0, MPI_COMM_WORLD);
            if (send_buf) free(send_buf);
            
            int total_sia=0, total_siac=0, total_siahe=0, total_v=0, total_vc=0, total_vhe=0;
            int total_nis=0, total_nvs=0, total_nhes=0;
            
            MPI_Reduce(&sia, &total_sia, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); MPI_Reduce(&siac, &total_siac, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); MPI_Reduce(&siahe, &total_siahe, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
            MPI_Reduce(&v, &total_v, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); MPI_Reduce(&vc, &total_vc, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); MPI_Reduce(&vhe, &total_vhe, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
            MPI_Reduce(&nis, &total_nis, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); MPI_Reduce(&nvs, &total_nvs, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); MPI_Reduce(&nhes, &total_nhes, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

            if (my_rank == 0) {
                fprintf(fp, "%le %le %le %le %le %le %le\n", global_time,
                        ((double)total_sia)/input_total_volume, ((double)total_siac)/input_total_volume, ((double)total_siahe)/input_total_volume, 
                        ((double)total_v)/input_total_volume,   ((double)total_vc)/input_total_volume,   ((double)total_vhe)/input_total_volume);
                
                struct ClusterStat *stat_hash = NULL, *s_obj, *s_tmp;
                for (int i = 0; i < total_ints; i += ints_per_cluster) {
                    int temp_attrs[LEVELS];
                    for (int k = 0; k < LEVELS; k++) temp_attrs[k] = recv_buf[i + k];
                    int count = recv_buf[i + LEVELS];
                    
                    HASH_FIND(hh, stat_hash, temp_attrs, LEVELS * sizeof(int), s_obj);
                    if (s_obj == NULL) {
                        s_obj = (struct ClusterStat *)malloc(sizeof(struct ClusterStat));
                        for(int k=0; k<LEVELS; k++) s_obj->attrs[k] = temp_attrs[k];
                        s_obj->total_count = count;
                        HASH_ADD(hh, stat_hash, attrs, LEVELS * sizeof(int), s_obj);
                    } else s_obj->total_count += count; 
                }
                
                FILE *f_sp = fopen("out/species.out", (i_step == 0) ? "w" : "a");
                if (f_sp) {
                    if (i_step == 0) fprintf(f_sp, "# [Cluster Distribution] Detailed species count tracked per output step.\n");
                    fprintf(f_sp, "--- Time: %le [s], Dose: %le [dpa] ---\n", global_time, global_time * DPA_RATE);
                    fprintf(f_sp, "Species(L0"); for(int k=1; k<LEVELS; k++) fprintf(f_sp, ",L%d", k); fprintf(f_sp, ")\tTotal_Count\n");
                    
                    HASH_SRT(hh, stat_hash, stat_sort); 
                    s_obj = stat_hash;
                    while (s_obj != NULL) {
                        s_tmp = (struct ClusterStat *)s_obj->hh.next;
                        fprintf(f_sp, "[%4d", s_obj->attrs[0]);
                        for(int k=1; k<LEVELS; k++) fprintf(f_sp, ", %2d", s_obj->attrs[k]);
                        fprintf(f_sp, "]\t%lld\n", s_obj->total_count);
                        HASH_DELETE(hh, stat_hash, s_obj); free(s_obj);
                        s_obj = s_tmp;
                    }
                    fprintf(f_sp, "\n"); fclose(f_sp);
                }
                
                if (recv_buf) free(recv_buf); free(recv_counts); free(displs);
                if (CHANNELS == 2) fprintf(fs, "%e %d %d %d\n", global_time, total_nis, total_nvs, total_nhes);
                else fprintf(fs, "%e %d %d\n", global_time, total_nis, total_nvs); 
                
                end = clock(); elapsed = (end - start) / (double)CLOCKS_PER_SEC;
                fprintf(ft, "%lld %lf\n", i_step, elapsed);
                fflush(stdout); fflush(fs); fflush(ft); fflush(f_tc);
            }
        }
        i_step++;
    } 

    if (my_rank == 0) { fclose(fp); fclose(ft); fclose(fs); fclose(f_tc); }
    if (d_local_meshes != NULL) hipFree(d_local_meshes);
    MPI_Finalize();
    return 0;
}