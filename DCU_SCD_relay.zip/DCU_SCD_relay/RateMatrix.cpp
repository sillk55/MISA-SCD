#include "RateMatrix.h"
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <math.h>
#include "types.h"

extern int64 i_step;
extern struct mesh_t *current_mesh; 

__host__ __device__ double computeDamages(struct RateMatrix *rateMatrix, double dpa) {
    #ifdef PKA
    rateMatrix->damage[0] = PKA_RATE * rateMatrix->m_volume; 
    #else
    rateMatrix->damage[0] = 0.0;
    #endif
    double agg_rate = rateMatrix->damage[0];
    if (CHANNELS > 1) {
        rateMatrix->damage[1] = (RE_RATE1 * dpa + RE_RATE0) * DPA_RATE * 1.0e-06 * DENSITY * rateMatrix->m_volume; 
        agg_rate += rateMatrix->damage[1];
    }
    return agg_rate;
}

struct RateMatrix *initialization(double m_vol, double l_vol, double lx, double ly, double lz) {
    struct RateMatrix *rateMatrix = (struct RateMatrix *)malloc(sizeof(struct RateMatrix));
    memset(rateMatrix, 0, sizeof(struct RateMatrix));
    rateMatrix->m_volume = m_vol; rateMatrix->l_volume = l_vol;
    rateMatrix->Lx = lx; rateMatrix->Ly = ly; rateMatrix->Lz = lz;
    rateMatrix->avol = ALATT * ALATT * ALATT / 2.0;
    rateMatrix->jumpd = sqrt(3.0) * ALATT / 2.0;
    compute_sinks(rateMatrix->ss);
    rateMatrix->totalRate = computeDamages(rateMatrix, 0.0);
    return rateMatrix;
}

__host__ __device__ void computeR1R1e(struct RateMatrix *rateMatrix, struct Material *material, struct object_t *objects_all) {
    struct object_t *obj = &objects_all[material->object_index];
    int ndef = obj->attributes[0]; double avol = rateMatrix->avol, jumpd = rateMatrix->jumpd;
    if (ndef <= 0) {
        material->r1 = zero(ndef) * pow(3.0 * fabs((double)ndef) * avol / 4.0 / PI, 0.333333333333333333);
        if (ndef != 0) material->r1e = pow(3.0 * (fabs((double)ndef) - 1) * avol / 4.0 / PI, 0.333333333333333333);
        else material->r1e = jumpd;
    } else if (ndef > 0) {
        material->r1 = zero(ndef) * sqrt((double)ndef * avol / jumpd / PI);
        material->r1e = zero(ndef) * sqrt(((double)ndef - 1) * avol / jumpd / PI);
    }
}

__host__ __device__ double computeZeroReaction(struct RateMatrix *rateMatrix, const struct object_t *P_1) { 
    double sink_strength = (P_1->attributes[0] < 0) ? rateMatrix->ss[0] : rateMatrix->ss[1];
    return P_1->number * P_1->diff * sink_strength;
}

__host__ __device__ double computeOneReaction(struct RateMatrix *rateMatrix, struct Material *material, int index, struct object_t *objects_all) { 
    struct object_t *P_1 = &objects_all[material->object_index];
    if (P_1->attributes[index] != 0) {
        int attr[LEVELS] = {0}; attr[index] = signof(P_1->attributes[index]);
        return (4.0 * PI * material->r1e / rateMatrix->avol) * compute_diff_coeff(attr) * P_1->binding[index] * ((double)P_1->number);
    } else return 0;
}

__host__ __device__ double computeJumpReaction(struct RateMatrix *rateMatrix, const struct object_t *P_1, int dir) {
    if (P_1->diff <= 0) return 0.0; 
    double dx = (dir < 2) ? rateMatrix->Lx : ((dir < 4) ? rateMatrix->Ly : rateMatrix->Lz);
    return (P_1->number * P_1->diff) / (dx * dx);
}

__host__ __device__ double computeTwoReaction(struct RateMatrix *rateMatrix, struct Material *material, const struct object_t *P_2, struct object_t *objects_all) { 
    struct object_t *P_1 = &objects_all[material->object_index];
    double concentration;
    if (P_1->key != P_2->key) {
        concentration = (double)P_1->number * (double)P_2->number / rateMatrix->m_volume;
        if (P_1->diff > 0 && P_2->diff > 0) concentration /= 2.0; 
    } else { concentration = (double)P_1->number * ((double)P_1->number - 1.0) / 2.0 / rateMatrix->m_volume; }
    
    int ndef = P_2->attributes[0]; double R_2, R12; double avol = rateMatrix->avol, jumpd = rateMatrix->jumpd;
    if (ndef > 0) R_2 = zero(ndef) * sqrt((double)ndef * avol / jumpd / PI);
    else R_2 = zero(ndef) * pow(3.0 * fabs((double)ndef) * avol / 4.0 / PI, 0.333333333333333333);
    
    R12 = material->r1 + R_2; if (R12 < R_IV) R12 = R_IV; 
    return 4.0 * PI * concentration * R12 * dimension_term(R12, P_1, P_2, rateMatrix->m_volume, rateMatrix->l_volume);
}

__host__ __device__ void removeSecondArrayColumn(struct RateMatrix *rateMatrix, int deleteIndex) {
    int lIndex, cIndex, swapSecondIndex;
    int secondLength = rateMatrix->secondLength, deleteSecondIndex = deleteIndex - ZF_LENGTH;
    int columnLength = ZF_LENGTH + secondLength;
    struct Reaction *columnHead = rateMatrix->columnHead;
    struct Material *lineHead = rateMatrix->lineHead;
    
    for (cIndex = columnLength - 1; cIndex > deleteIndex; --cIndex) { if (columnHead[cIndex].status == 's') break; }
    if (cIndex > deleteIndex) { 
        swapSecondIndex = cIndex - ZF_LENGTH;
        for (lIndex = 0; lIndex < rateMatrix->lineLength; ++lIndex) {
            double *secondArray = lineHead[lIndex].rates + ZF_LENGTH;
            rateMatrix->totalRate -= secondArray[deleteSecondIndex];
            secondArray[deleteSecondIndex] = secondArray[swapSecondIndex];
        }
        columnHead[deleteIndex] = columnHead[cIndex];
        rateMatrix->secondLength = swapSecondIndex;
    } else {
        for (lIndex = 0; lIndex < rateMatrix->lineLength; ++lIndex) rateMatrix->totalRate -= lineHead[lIndex].rates[ZF_LENGTH + deleteSecondIndex];
        if (deleteSecondIndex < secondLength) rateMatrix->secondLength = deleteSecondIndex;
    }
}

__host__ __device__ void recordColumnHead(struct RateMatrix *rateMatrix, int requestSecondLength, struct object_t *objects_all) {
    int columnLength = ZF_LENGTH + rateMatrix->secondLength;
    struct Reaction *columnHead = rateMatrix->columnHead;
    if (requestSecondLength > MAX_SPECIES) return; 
    int cIndex = columnLength;
    for (int i = 0; i < rateMatrix->newMobileLength; ++i, ++cIndex) {
        columnHead[cIndex].object_index = rateMatrix->newMobiles[i];
        columnHead[cIndex].object_key = objects_all[rateMatrix->newMobiles[i]].key;
    }
}

// 👑 [并发大招 1]: 并行多线程计算双粒子截面 O(N^2)
__host__ __device__ void calculateSecondColumnAndEnlargeIfNeed(struct RateMatrix *rateMatrix, struct object_t *objects_all) {
    int t_idx = 0, t_dim = 1;
    #ifdef __HIP_DEVICE_COMPILE__
    t_idx = threadIdx.x; t_dim = blockDim.x;
    #endif

    int requestSecondLength = rateMatrix->secondLength + rateMatrix->newMobileLength;
    if (t_idx == 0) recordColumnHead(rateMatrix, requestSecondLength, objects_all);
    
    #ifdef __HIP_DEVICE_COMPILE__
    __syncthreads();
    #endif

    struct Material *lineHead = rateMatrix->lineHead;
    int lineLength = rateMatrix->lineLength;
    int secondLength = rateMatrix->secondLength;
    double local_addRate = 0.0, rate;
    
    int total_tasks = lineLength * (requestSecondLength - secondLength);
    if (total_tasks > 0) {
        // GPU的256个线程像狼群一样分食这个庞大的矩阵循环
        for (int i = t_idx; i < total_tasks; i += t_dim) {
            int lIndex = i / (requestSecondLength - secondLength);
            int cSecondIndex = secondLength + (i % (requestSecondLength - secondLength));
            
            struct Material *material = &lineHead[lIndex];
            double *secondArray = material->rates + ZF_LENGTH;
            struct Reaction *columnHead = rateMatrix->columnHead;
            
            struct object_t *mobileObject = &objects_all[columnHead[cSecondIndex + ZF_LENGTH].object_index];
            rate = computeTwoReaction(rateMatrix, material, mobileObject, objects_all);
            local_addRate += rate;
            secondArray[cSecondIndex] = rate;
        }

        // 安全地将结果汇总回显存
        if (local_addRate != 0.0) {
            #ifdef __HIP_DEVICE_COMPILE__
            atomicAdd(&(rateMatrix->totalRate), local_addRate);
            #else
            rateMatrix->totalRate += local_addRate;
            #endif
        }
    }

    #ifdef __HIP_DEVICE_COMPILE__
    __syncthreads();
    #endif
    
    if (t_idx == 0) rateMatrix->secondLength = requestSecondLength;
}

__host__ __device__ struct Material *addLine(struct RateMatrix *rateMatrix, int newObjectIndex, struct object_t *objects_all) {
    if (rateMatrix->lineLength >= MAX_SPECIES) return NULL;
    struct Material *newMaterial = &rateMatrix->lineHead[rateMatrix->lineLength];
    newMaterial->object_index = newObjectIndex;
    newMaterial->object_key = objects_all[newObjectIndex].key;
    for(int i=0; i<ZF_LENGTH + MAX_SPECIES; i++) newMaterial->rates[i] = 0.0;
    ++rateMatrix->lineLength;
    return newMaterial;
}

__host__ __device__ void computeLine(struct RateMatrix *rateMatrix, struct Material *material, char status, struct object_t *objects_all) {
    struct object_t *obj = &objects_all[material->object_index];
    double *arrayzf = material->rates; double *arrays = material->rates + ZF_LENGTH;
    double rate, addRate = 0.0;
    
    computeR1R1e(rateMatrix, material, objects_all);
    rate = computeZeroReaction(rateMatrix, obj);
    if (status == 'a') addRate += rate; else addRate += rate - arrayzf[0];
    arrayzf[0] = rate;

    for (int cFirstIndex = 0; cFirstIndex < LEVELS; ++cFirstIndex) {
        rate = computeOneReaction(rateMatrix, material, cFirstIndex, objects_all);
        if (status == 'a') addRate += rate; else addRate += rate - arrayzf[cFirstIndex + 1];
        arrayzf[cFirstIndex + 1] = rate;
    }

    for (int d = 0; d < JUMP_CHANNELS; ++d) {
        rate = computeJumpReaction(rateMatrix, obj, d);
        if (status == 'a') addRate += rate; else addRate += rate - arrayzf[LEVELS + 1 + d];
        arrayzf[LEVELS + 1 + d] = rate;
    }

    for (int cSecondIndex = 0; cSecondIndex < rateMatrix->secondLength; ++cSecondIndex) {
        struct object_t *mobileObj = &objects_all[rateMatrix->columnHead[ZF_LENGTH + cSecondIndex].object_index];
        rate = computeTwoReaction(rateMatrix, material, mobileObj, objects_all);
        if (status == 'a') addRate += rate; else addRate += rate - arrays[cSecondIndex];
        arrays[cSecondIndex] = rate;
    }
    rateMatrix->totalRate += addRate;
}

// 👑 [并发大招 2]: Master-Worker 协作更新组
__host__ __device__ void addRemoveInRateMatrix(struct RateMatrix *rateMatrix, struct object_t *objects_all, int active_objects_count) {
    int t_idx = 0;
    #ifdef __HIP_DEVICE_COMPILE__
    t_idx = threadIdx.x;
    #endif

    // 包工头 Thread 0 负责查户口和记账
    if (t_idx == 0) {
        struct Reaction *columnHead = rateMatrix->columnHead;
        int cIndex, columnLength = ZF_LENGTH + rateMatrix->secondLength;
        for (cIndex = ZF_LENGTH; cIndex < columnLength; ++cIndex) columnHead[cIndex].status = 'd';

        int check_exist[MAX_SPECIES];
        for (int i = 0; i < rateMatrix->secondLength; i++) check_exist[i] = 0;
            
        if (objects_all != NULL) {
            for (cIndex = ZF_LENGTH; cIndex < columnLength; ++cIndex) {
                for (int i = 0; i < active_objects_count; i++) {
                    if (columnHead[cIndex].object_key == objects_all[i].key) {
                        check_exist[cIndex - ZF_LENGTH] = 1; 
                        columnHead[cIndex].object_index = i; 
                        break;
                    }
                }
            }
            for (int i = 0; i < active_objects_count; i++) {
                struct object_t *mobileObject = &objects_all[i];
                if (mobileObject->diff <= 0) continue;
                for (cIndex = ZF_LENGTH; cIndex < columnLength; ++cIndex) {
                    if (check_exist[cIndex - ZF_LENGTH] == 1 && mobileObject->key == columnHead[cIndex].object_key) { 
                        columnHead[cIndex].status = 's'; break;
                    }
                }
                if (cIndex == columnLength) { rateMatrix->newMobiles[rateMatrix->newMobileLength++] = i; }
            }
        }
        for (cIndex = ZF_LENGTH; cIndex < columnLength; ++cIndex) {
            if (columnHead[cIndex].status == 'd') removeSecondArrayColumn(rateMatrix, cIndex);
        }
    }
    
    #ifdef __HIP_DEVICE_COMPILE__
    __syncthreads(); // 等待包工头查账完毕
    #endif
    
    // 全员并肩子上：极其耗时的矩阵大重构
    calculateSecondColumnAndEnlargeIfNeed(rateMatrix, objects_all);

    if (t_idx == 0) {
        for (int i = 0; i < rateMatrix->newMaterialLength; i++) {
            struct Material *material = addLine(rateMatrix, rateMatrix->newMaterials[i], objects_all);
            if (material != NULL) computeLine(rateMatrix, material, 'a', objects_all);
        }
        rateMatrix->newMaterialLength = 0; rateMatrix->newMobileLength = 0;
    }
    
    #ifdef __HIP_DEVICE_COMPILE__
    __syncthreads();
    #endif
}

__host__ __device__ void deleteLine(struct RateMatrix *rateMatrix, int64 key, struct object_t *objects_all) {
    struct Material *lineHead = rateMatrix->lineHead;
    int lineLength = rateMatrix->lineLength;
    int lIndex;
    for (lIndex = 0; lIndex < lineLength; ++lIndex) { if (lineHead[lIndex].object_key == key) break; }
    
    if (lIndex == lineLength) {
        for (int i = 0; i < rateMatrix->newMaterialLength; i++) {
            if (objects_all[rateMatrix->newMaterials[i]].key == key) {
                rateMatrix->newMaterials[i] = rateMatrix->newMaterials[rateMatrix->newMaterialLength - 1];
                rateMatrix->newMaterialLength--;
                return;
            }
        }
        return;
    }

    double *zeroFirstArray = lineHead[lIndex].rates;
    double *secondArray = lineHead[lIndex].rates + ZF_LENGTH;
    double minusRate = 0.0;
    
    for (int cZFIndex = 0; cZFIndex < ZF_LENGTH; ++cZFIndex) minusRate += zeroFirstArray[cZFIndex];
    for (int cSIndex = 0; cSIndex < rateMatrix->secondLength; ++cSIndex) minusRate += secondArray[cSIndex];
    
    rateMatrix->totalRate -= minusRate;
    lineHead[lIndex] = lineHead[lineLength - 1];
    
    for(int i=0; i<ZF_LENGTH + MAX_SPECIES; i++) lineHead[lineLength - 1].rates[i] = 0.0;
    lineHead[lineLength - 1].object_key = 0; lineHead[lineLength - 1].object_index = 0;
    --rateMatrix->lineLength;

    for (int cIndex = ZF_LENGTH; cIndex < ZF_LENGTH + rateMatrix->secondLength; ++cIndex) {
        if (rateMatrix->columnHead[cIndex].object_key == key) { removeSecondArrayColumn(rateMatrix, cIndex); break; }
    }
}

__host__ __device__ void computeSecondArrayColumn(struct RateMatrix *rateMatrix, int secondIndex, struct object_t *objects_all) {
    struct Material *lineHead = rateMatrix->lineHead;
    double changeRate = 0.0, rate;
    struct object_t *mobileObject = &objects_all[rateMatrix->columnHead[ZF_LENGTH + secondIndex].object_index];

    for (int lIndex = 0; lIndex < rateMatrix->lineLength; ++lIndex) {
        double *secondArray = lineHead[lIndex].rates + ZF_LENGTH;
        rate = computeTwoReaction(rateMatrix, lineHead + lIndex, mobileObject, objects_all);
        changeRate += rate - secondArray[secondIndex];
        secondArray[secondIndex] = rate;
    }
    rateMatrix->totalRate += changeRate;
}

__host__ __device__ void update(struct RateMatrix *rateMatrix, int64 key, struct object_t *objects_all) {
    struct Material *lineHead = rateMatrix->lineHead;
    struct Reaction *columnHead = rateMatrix->columnHead;
    for (int lIndex = 0; lIndex < rateMatrix->lineLength; ++lIndex) {
        if (lineHead[lIndex].object_key == key) { computeLine(rateMatrix, lineHead + lIndex, 'u', objects_all); break; }
    }
    for (int cIndex = ZF_LENGTH; cIndex < rateMatrix->secondLength + ZF_LENGTH; ++cIndex) {
        if (columnHead[cIndex].object_key == key) { computeSecondArrayColumn(rateMatrix, cIndex - ZF_LENGTH, objects_all); break; }
    }
}

__host__ __device__ void selectReaction(struct RateMatrix *rateMatrix, int *lIndex, int *cIndex, double xi2) {
    double randRate = rateMatrix->totalRate * xi2; double addRate = 0.0;
    for (int tlIndex = 0; tlIndex < rateMatrix->lineLength; ++tlIndex) {
        double *zeroFirstArray = rateMatrix->lineHead[tlIndex].rates;
        for (int tcZFIndex = 0; tcZFIndex < ZF_LENGTH; ++tcZFIndex) {
            addRate += zeroFirstArray[tcZFIndex];
            if (addRate > randRate) { *lIndex = tlIndex; *cIndex = tcZFIndex; return; }
        }
        double *secondArray = rateMatrix->lineHead[tlIndex].rates + ZF_LENGTH;
        for (int tcSIndex = 0; tcSIndex < rateMatrix->secondLength; ++tcSIndex) {
            addRate += secondArray[tcSIndex];
            if (addRate > randRate) { *lIndex = tlIndex; *cIndex = tcSIndex + ZF_LENGTH; return; }
        }
    }
    for (int tcZFIndex = 0; tcZFIndex < CHANNELS; ++tcZFIndex) {
        addRate += rateMatrix->damage[tcZFIndex];
        if (addRate > randRate) { *lIndex = -1; *cIndex = tcZFIndex; return; }
    }
    *lIndex = -1; *cIndex = CHANNELS - 1;
}

// 👑 [并发大招 3]: 瞬间并归计算宏观总速率
__host__ __device__ void calibrateTotalRate(struct RateMatrix *rateMatrix) {
    int t_idx = 0, t_dim = 1;
    #ifdef __HIP_DEVICE_COMPILE__
    t_idx = threadIdx.x; t_dim = blockDim.x;
    #endif

    double local_sum = 0.0;
    int total_tasks = rateMatrix->lineLength;
    
    // 多线程狼群分食累加任务
    for (int lIndex = t_idx; lIndex < total_tasks; lIndex += t_dim) {
        double line_sum = 0.0;
        for (int i = 0; i < ZF_LENGTH; ++i) line_sum += rateMatrix->lineHead[lIndex].rates[i];
        for (int i = 0; i < rateMatrix->secondLength; ++i) line_sum += rateMatrix->lineHead[lIndex].rates[ZF_LENGTH + i];
        local_sum += line_sum;
    }

    if (t_idx == 0) {
        double dam_sum = 0.0;
        for (int i = 0; i < CHANNELS; i++) dam_sum += rateMatrix->damage[i];
        rateMatrix->totalRate = dam_sum;
    }
    
    #ifdef __HIP_DEVICE_COMPILE__
    __syncthreads();
    #endif

    if (local_sum != 0.0) {
        #ifdef __HIP_DEVICE_COMPILE__
        atomicAdd(&(rateMatrix->totalRate), local_sum);
        #else
        rateMatrix->totalRate += local_sum;
        #endif
    }
    
    #ifdef __HIP_DEVICE_COMPILE__
    __syncthreads();
    #endif
}

void sync_matrix_indices(struct RateMatrix *rateMatrix) {
    if (!rateMatrix || !current_mesh) return;
    for (int i = 0; i < rateMatrix->lineLength; i++) {
        int64 key = rateMatrix->lineHead[i].object_key;
        for(int j=0; j<current_mesh->active_objects_count; j++) {
            if(current_mesh->objects_all[j].key == key) { rateMatrix->lineHead[i].object_index = j; break; }
        }
    }
    for (int i = ZF_LENGTH; i < ZF_LENGTH + rateMatrix->secondLength; i++) {
        int64 key = rateMatrix->columnHead[i].object_key;
        for(int j=0; j<current_mesh->active_objects_count; j++) {
            if(current_mesh->objects_all[j].key == key) { rateMatrix->columnHead[i].object_index = j; break; }
        }
    }
}

void update_matrix_object_index(struct RateMatrix *rateMatrix, int64 key, int new_index) {
    if (!rateMatrix) return;
    for (int i = 0; i < rateMatrix->lineLength; i++) {
        if (rateMatrix->lineHead[i].object_key == key) { rateMatrix->lineHead[i].object_index = new_index; break; }
    }
    for (int i = ZF_LENGTH; i < ZF_LENGTH + rateMatrix->secondLength; i++) {
        if (rateMatrix->columnHead[i].object_key == key) { rateMatrix->columnHead[i].object_index = new_index; break; }
    }
}

__host__ __device__ void insert_single_particle(int64 e_key, int number, struct mesh_t *mesh) {
    struct RateMatrix *rateMatrix = mesh->matrix;
    struct object_t *objects_all = mesh->objects_all;
    int found = 0;
    for (int i=0; i < mesh->active_objects_count; i++) {
        if (objects_all[i].key == e_key) {
            objects_all[i].number += number;
            if (rateMatrix) update(rateMatrix, e_key, objects_all);
            found = 1; break;
        }
    }
    if (!found) {
        int attr[LEVELS]; get_attributes(e_key, attr);
        int dim = (attr[0] > 4) ? 1 : 3;
        double bind_out[LEVELS]; compute_bind_term(attr, bind_out);
        int idx = mesh->active_objects_count;
        if (idx >= MAX_SPECIES) return; 
        
        objects_all[idx].key = e_key; objects_all[idx].number = number; objects_all[idx].dimensionality = dim; objects_all[idx].diff = compute_diff_coeff(attr);
        for(int l=0; l<LEVELS; l++) { objects_all[idx].attributes[l] = attr[l]; objects_all[idx].binding[l] = bind_out[l]; }
        mesh->active_objects_count++;
        if (rateMatrix) rateMatrix->newMaterials[rateMatrix->newMaterialLength++] = idx;
    }
}

__host__ __device__ void process_event_gpu(struct object_t *my_object, int64 k2, int n2, struct mesh_t *mesh) {
    int64 mono_key = 0, cluster_key = 0; int attr[LEVELS], att[LEVELS] = {0};
    struct RateMatrix *rateMatrix = mesh->matrix;

    if (n2 == 0) {
        my_object->number--;
        if (rateMatrix) update(rateMatrix, my_object->key, mesh->objects_all);
    } else if ((n2 > 0) && (n2 <= LEVELS)) {
        mono_key = signof(my_object->attributes[n2 - 1]) * ((int64)pow(10.0, (double)EXP10 * (LEVELS - n2))); 
        get_attributes(mono_key, attr);
        cluster_key = (int64)signof(my_object->attributes[0]) * (int64)(llabs(my_object->key) - llabs(mono_key));
        if (cluster_key < 0 && cluster_key > -1 * pow(10, (LEVELS - 1) * 3)) cluster_key *= -1; 
        insert_single_particle(mono_key, 1, mesh); insert_single_particle(cluster_key, 1, mesh);
        my_object->number--;
        if (rateMatrix) update(rateMatrix, my_object->key, mesh->objects_all);
    } else if (n2 > LEVELS) {
        struct object_t *other_object = NULL;
        for(int i=0; i < mesh->active_objects_count; i++) { if(mesh->objects_all[i].key == k2) { other_object = &mesh->objects_all[i]; break; } }
        if(!other_object) return;

        for (int i = 0; i < LEVELS; i++) {
            att[i] = my_object->attributes[i] + other_object->attributes[i];
            cluster_key += labs(att[i]) * ((int64)pow(10.0, (double)EXP10 * (LEVELS - 1 - i)));
        }
        cluster_key *= signof(att[0]);
        insert_single_particle(cluster_key, 1, mesh);
        my_object->number--; other_object->number--;
        if (rateMatrix) { update(rateMatrix, my_object->key, mesh->objects_all); update(rateMatrix, other_object->key, mesh->objects_all); }
    }
}

__host__ __device__ void get_insertion_gpu(int channel, struct mesh_t *mesh, unsigned int *seed, double *d_PKA_energy, double *d_p_of_PKA_energy, int *d_num_of_Cas_per_energy, struct cascade_def **d_casdef) {
    int64 e_key = 0;
    if (channel == 0) {
        double xi1 = lcg_rand(seed); double xi2 = lcg_rand(seed);
        int id1 = 0, id2 = 0; double sump = 0;
        for (int i = 0; i < 11; i++) { 
            if (sump <= xi1 && sump + d_p_of_PKA_energy[i] > xi1) { id1 = i; id2 = (int)(d_num_of_Cas_per_energy[i] * xi2); break; } else { sump += d_p_of_PKA_energy[i]; }
        }
        for (int k = 0; k < d_casdef[id1][id2].nvdef; k++) {
            int vsize = d_casdef[id1][id2].vsize[k], vnum = d_casdef[id1][id2].vnum[k];
            if (vsize > 0 && vnum > 0) { e_key = -1 * vsize * (int64)(pow(10.0, EXP10 * (LEVELS - 1))); insert_single_particle(e_key, vnum, mesh); }
        }
        for (int k = 0; k < d_casdef[id1][id2].nidef; k++) {
            int isize = d_casdef[id1][id2].isize[k], inum = d_casdef[id1][id2].inum[k];
            if (isize > 0 && inum > 0) { e_key = 1 * isize * (int64)(pow(10.0, EXP10 * (LEVELS - 1))); insert_single_particle(e_key, inum, mesh); }
        }
    } else if (channel == 1) {
        if (lcg_rand(seed) < 0.0) e_key = -1 * ((int64)pow(10.0, (double)EXP10 * (LEVELS - 1)) + (int64)pow(10.0, (double)EXP10 * (LEVELS - 2)));
        else e_key = (int64)pow(10.0, (double)EXP10 * (LEVELS - 2));
        insert_single_particle(e_key, 1, mesh);
    }
}

// 👑 [并发大招 4]: Block 级共享内存主循环
__global__ void kmc_evolution_kernel(struct mesh_t *local_meshes, int *mesh_ids, int num_meshes, double global_time, double tau_kmc, unsigned int base_seed, double *d_PKA_energy, double *d_p_of_PKA_energy, int *d_num_of_Cas_per_energy, struct cascade_def **d_casdef) {
    int m_idx = blockIdx.x; 
    if (m_idx >= num_meshes) return;

    int m = mesh_ids[m_idx];
    struct mesh_t *mesh = &local_meshes[m];
    struct RateMatrix *rateMatrix = mesh->matrix;

    unsigned int seed = base_seed + m; 
    
    __shared__ double shared_mesh_time;
    __shared__ int shared_break_flag;
    __shared__ int shared_lIndex;
    __shared__ int shared_cIndex;
    __shared__ double shared_dt;

    if (threadIdx.x == 0) {
        shared_mesh_time = 0.0;
        shared_break_flag = 0;
        computeDamages(rateMatrix, global_time * DPA_RATE); 
    }
    __syncthreads();

    while (true) {
        if (threadIdx.x == 0) { computeDamages(rateMatrix, (global_time + shared_mesh_time) * DPA_RATE); }
        __syncthreads();

        calibrateTotalRate(rateMatrix); // 全员上阵并发求和！

        if (threadIdx.x == 0) {
            if (rateMatrix->totalRate <= 0) shared_break_flag = 1;
            else {
                shared_dt = -log(lcg_rand(&seed)) / rateMatrix->totalRate;
                if (shared_mesh_time + shared_dt > tau_kmc) shared_break_flag = 1;
                else selectReaction(rateMatrix, &shared_lIndex, &shared_cIndex, lcg_rand(&seed));
            }
        }
        __syncthreads();

        if (shared_break_flag) break;

        if (threadIdx.x == 0) {
            if (shared_lIndex == -1) {
                get_insertion_gpu(shared_cIndex, mesh, &seed, d_PKA_energy, d_p_of_PKA_energy, d_num_of_Cas_per_energy, d_casdef);
            } else {
                struct Material *material = rateMatrix->lineHead + shared_lIndex;
                struct object_t *event_object = &mesh->objects_all[material->object_index];
                int is_jump = 0, jump_dir = -1; int64 k2 = 0;

                if (shared_cIndex == 0) { k2 = 0; }
                else if (shared_cIndex < LEVELS + 1) { k2 = 0; }
                else if (shared_cIndex < ZF_LENGTH) { is_jump = 1; jump_dir = shared_cIndex - (LEVELS + 1); } 
                else { struct Reaction *reaction = rateMatrix->columnHead + shared_cIndex; k2 = reaction->object_key; }

                if (is_jump) {
                    int target_id = mesh->neighbor_ids[jump_dir];
                    struct mesh_t *target_mesh = &local_meshes[target_id];
                    int64 j_key = event_object->key;

                    event_object->number--; update(rateMatrix, j_key, mesh->objects_all);
                    lock_mesh(&target_mesh->lock);
                    insert_single_particle(j_key, 1, target_mesh);
                    unlock_mesh(&target_mesh->lock);
                } else {
                    process_event_gpu(event_object, k2, shared_cIndex, mesh);
                }
            }
            shared_mesh_time += shared_dt;
        }
        __syncthreads();

        // 全员上阵重新构造庞大的碰撞矩阵！
        addRemoveInRateMatrix(rateMatrix, mesh->objects_all, mesh->active_objects_count); 
    }
}

// 👑 [并发大招 5]: Block 级最大速率探路者
__global__ void calc_max_rate_kernel(struct mesh_t *local_meshes, int num_total_meshes, double global_time, double *d_max_rates) {
    int m = blockIdx.x; 
    if (m >= num_total_meshes) return;
    
    struct mesh_t *mesh = &local_meshes[m];
    if (mesh->is_ghost) { if (threadIdx.x == 0) d_max_rates[m] = 0.0; return; }
    
    struct RateMatrix *rateMatrix = mesh->matrix;
    addRemoveInRateMatrix(rateMatrix, mesh->objects_all, mesh->active_objects_count);
    
    if (threadIdx.x == 0) computeDamages(rateMatrix, global_time * DPA_RATE);
    __syncthreads();

    calibrateTotalRate(rateMatrix);
    
    if (threadIdx.x == 0) d_max_rates[m] = rateMatrix->totalRate;
}