import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. 读取数据
# tc.txt 第一行是带有 '#' 的注释，使用 comment='#' 跳过
# 根据 tc.txt 内容，共有 4 列数据，分别对应: Step, Comp, Wait, Pack
data_file = 'tc.txt'
try:
    df = pd.read_csv(data_file, sep='\t', comment='#', header=None, 
                     names=['Step', 'Comp', 'Wait', 'Pack'])
except FileNotFoundError:
    print(f"错误: 找不到文件 {data_file}，请确保脚本与数据文件在同一目录下。")
    exit()

# 2. 数据处理：计算百分比
# 将 Wait 和 Pack 合并为总的 Communication 时间
df['Comm'] = df['Wait'] + df['Pack']
df['Total'] = df['Comp'] + df['Comm']

# 计算百分比
df['Comp_Pct'] = (df['Comp'] / df['Total']) * 100
df['Comm_Pct'] = (df['Comm'] / df['Total']) * 100

# 将 Step 转换为字符串，以便在柱状图上作为类别标签均匀等距显示
x_labels = df['Step'].astype(int).astype(str).tolist()

# 3. 开始绘图
fig, ax = plt.subplots(figsize=(14, 7))

# 柱子的 x 坐标
x_pos = np.arange(len(df))

# 绘制 Computation 柱子 (底部)
bars_comp = ax.bar(x_pos, df['Comp_Pct'], color='#4C72B0', edgecolor='white', width=0.85, label='Computation %')

# 绘制 Communication 柱子 (堆叠在 Computation 之上)
bars_comm = ax.bar(x_pos, df['Comm_Pct'], bottom=df['Comp_Pct'], color='#F59646', edgecolor='white', width=0.85, label='Communication %')

# 4. 在柱子内部添加百分比文本标签
for i in range(len(df)):
    comp_val = df['Comp_Pct'].iloc[i]
    comm_val = df['Comm_Pct'].iloc[i]
    
    # 标出 Computation 的百分比 (放在蓝色柱子中间偏上一点)
    if comp_val > 5:  # 只有当高度足够时才显示文字
        ax.text(x_pos[i], comp_val / 2, f'{comp_val:.1f}%', 
                ha='center', va='center', color='white', fontsize=9, fontweight='bold')
        
    # 标出 Communication 的百分比 (放在橙色柱子中间)
    if comm_val > 5:
        ax.text(x_pos[i], comp_val + comm_val / 2, f'{comm_val:.1f}%', 
                ha='center', va='center', color='white', fontsize=9, fontweight='bold')

# 5. 图表格式美化
ax.set_title('Relative Ratio: Computation vs Communication (%)', fontsize=14, fontweight='bold', pad=15)
ax.set_xlabel('Simulation Step', fontsize=12)
ax.set_ylabel('Percentage (%)', fontsize=12)

# 设置 X 轴刻度和标签
ax.set_xticks(x_pos)
ax.set_xticklabels(x_labels, rotation=45, ha='right')

# 设置 Y 轴范围为 0 到 100
ax.set_ylim(0, 100)

# 添加图例 (放在图表右侧外部)
ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0., fontsize=11)

# 去除顶部和右侧的边框线条，使图表更清爽
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# 紧凑布局以防标签被截断
plt.tight_layout()

# 保存并显示高清图像
plt.savefig('performance_ratio.png', dpi=300, bbox_inches='tight')
print("图表已成功生成并保存为 performance_ratio.png")
plt.show()