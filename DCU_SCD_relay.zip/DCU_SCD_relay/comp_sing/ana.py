import os
import re
import pandas as pd
import matplotlib.pyplot as plt
import sys

# ==========================================
# >>> 用户配置区域 >>>
# ==========================================
# 输入文件名
FILE_STANDALONE = 'species_stand_v1.txt' # 串行版格式
FILE_PARALLEL_4 = 'species_4_v2.out'     # MPI并行版格式 (原 4x4x4)
FILE_PARALLEL_10 = 'species_10_v2.out'   # MPI并行版格式 (新增 10x10x10)

# 输出目录
OUTPUT_DIR = 'ana_sing'

# “较多粒子”的定义阈值：如果在任何一个时间点，数量超过该值，则被视为主要粒子。
COUNT_THRESHOLD = 1000  # 建议根据您的体系大小调整（例如 100, 1000）

# 串行版本的 Key 解码 EXP10 设置，需要与代码中 constant.h 保持一致
SERIAL_EXP10 = 7.0
# ==========================================


def sanitise_filename(species_name):
    """将 [ -1, 7] 格式的名称转换为 safe_filename_neg1_7.png"""
    # 移除方括号
    name = species_name.replace('[', '').replace(']', '').strip()
    # 替换空格和逗号为下划线
    name = re.sub(r'[,\s]+', '_', name)
    # 替换负号为 neg
    name = name.replace('-', 'neg')
    return f"spe_{name}.png"

def decode_serial_key(key):
    """
    将串行版的 object key（例如 -10000007）解码为标准格式 [V/SIA, Re]。
    根据提供的 get_attributes 逻辑 [L0 = key/EXP10, L1 = |key|%EXP10]
    """
    key_int = int(key)
    factor = int(10**SERIAL_EXP10)
    
    # 获取 Re 数量 (L1)
    re_count = abs(key_int) % factor
    
    # 获取 Vacancy/SIA 数量 (L0)
    if key_int < 0:
        v_sia_count = -(abs(key_int) // factor)
    else:
        v_sia_count = key_int // factor
        
    return f"[{v_sia_count:4d}, {re_count:2d}]"

def parse_standalone_file(filename):
    """解析串行版本（Stand-alone）的时间序列数据"""
    print(f">>> 正在解析串行版文件: {filename} ...")
    
    if not os.path.exists(filename):
        print(f"⚠️  警告: 找不到文件 {filename}，将跳过该串行数据的绘制。")
        return pd.DataFrame(columns=['Time', 'Species', 'Count_Stand'])
        
    data = []
    current_time = None
    
    re_time = re.compile(r'Aggregate time = ([\d.e+-]+)')
    re_data = re.compile(r'object\s+(-?\d+),\s*number\s+(\d+)')
    
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            
            # 匹配时间点
            time_match = re_time.search(line)
            if time_match:
                current_time = float(time_match.group(1))
                continue
            
            # 匹配数据项
            if current_time is not None:
                data_match = re_data.search(line)
                if data_match:
                    key = data_match.group(1)
                    count = int(data_match.group(2))
                    species_std = decode_serial_key(key)
                    data.append({'Time': current_time, 'Species': species_std, 'Count_Stand': count})

    df = pd.DataFrame(data)
    if df.empty:
        print(f"⚠️  警告: 文件 {filename} 中未解析到有效数据。")
        return pd.DataFrame(columns=['Time', 'Species', 'Count_Stand'])
        
    print(f"    -> 成功解析 {len(df['Time'].unique())} 个时间点，共 {len(df)} 行数据。")
    return df

def parse_parallel_file(filename, count_col_name):
    """解析并行版本（MPI/species.out 系列）的时间序列数据"""
    print(f">>> 正在解析并行版文件: {filename} ...")
    
    if not os.path.exists(filename):
        print(f"⚠️  警告: 找不到文件 {filename}，将跳过该并行数据的绘制。")
        return pd.DataFrame(columns=['Time', 'Species', count_col_name])
        
    data = []
    current_time = None
    
    # --- Time: 1.280000e+04 [s], Dose: 4.556800e-03 [dpa] ---
    re_time = re.compile(r'--- Time: ([\d.e+-]+) \[s\]')
    # [ -1, 7] 10709
    re_data = re.compile(r'\[\s*(-?\d+),\s*(\d+)\]\s+(\d+)')
    
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            
            # 匹配时间点
            time_match = re_time.search(line)
            if time_match:
                current_time = float(time_match.group(1))
                continue
            
            # 匹配数据项
            if current_time is not None:
                data_match = re_data.search(line)
                if data_match:
                    l0 = int(data_match.group(1))
                    l1 = int(data_match.group(2))
                    count = int(data_match.group(3))
                    # 标准化为和串行版一样的格式 "[ -1,  7]"
                    species_std = f"[{l0:4d}, {l1:2d}]"
                    data.append({'Time': current_time, 'Species': species_std, count_col_name: count})

    df = pd.DataFrame(data)
    if df.empty:
        print(f"⚠️  警告: 文件 {filename} 中未解析到有效数据。")
        return pd.DataFrame(columns=['Time', 'Species', count_col_name])
        
    print(f"    -> 成功解析 {len(df['Time'].unique())} 个时间点，共 {len(df)} 行数据。")
    return df

def main():
    # 1. 解析三个可能存在的文件
    df_stand = parse_standalone_file(FILE_STANDALONE)
    df_para_4 = parse_parallel_file(FILE_PARALLEL_4, 'Count_Para_4')
    df_para_10 = parse_parallel_file(FILE_PARALLEL_10, 'Count_Para_10')
    
    print("\n>>> 正在进行数据对齐和筛选...")
    
    # 2. 筛选“主要粒子” (Major Species) 集合并集
    major_species = set()
    
    if not df_stand.empty:
        m_stand = df_stand.groupby('Species')['Count_Stand'].max()
        major_species.update(m_stand[m_stand > COUNT_THRESHOLD].index)
        
    if not df_para_4.empty:
        m_para_4 = df_para_4.groupby('Species')['Count_Para_4'].max()
        major_species.update(m_para_4[m_para_4 > COUNT_THRESHOLD].index)
        
    if not df_para_10.empty:
        m_para_10 = df_para_10.groupby('Species')['Count_Para_10'].max()
        major_species.update(m_para_10[m_para_10 > COUNT_THRESHOLD].index)
    
    all_major_species = sorted(list(major_species))
    
    print(f"    -> 筛选出主要粒子共 {len(all_major_species)} 种 (数量 > {COUNT_THRESHOLD})")
    
    if not all_major_species:
        print("    -> 没有数量超过阈值的粒子，程序停止。")
        return

    # 3. 创建输出目录
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        print(f"\n>>> 已创建输出目录: {OUTPUT_DIR}")
    else:
        print(f"\n>>> 输出目录已存在: {OUTPUT_DIR} (将覆盖同名图片)")

    # 4. 循环为每种主要粒子生成折线图
    print("\n>>> 开始生成折线图...")
    for species in all_major_species:
        plt.figure(figsize=(10, 6))
        
        # 绘制串行线 (如果非空)
        if not df_stand.empty:
            s_stand = df_stand[df_stand['Species'] == species].sort_values('Time')
            if not s_stand.empty:
                plt.plot(s_stand['Time'], s_stand['Count_Stand'], 
                         label='Standalone (Serial)', 
                         color='#1f77b4', linewidth=2.5, marker='o', markersize=4, alpha=0.8)
            
        # 绘制并行线 4x4x4 (如果非空)
        if not df_para_4.empty:
            s_para_4 = df_para_4[df_para_4['Species'] == species].sort_values('Time')
            if not s_para_4.empty:
                plt.plot(s_para_4['Time'], s_para_4['Count_Para_4'], 
                         label='Parallel (4x4x4)', 
                         color='#ff7f0e', linewidth=2.5, marker='x', markersize=5, linestyle='--')

        # 绘制并行线 10x10x10 (如果非空)
        if not df_para_10.empty:
            s_para_10 = df_para_10[df_para_10['Species'] == species].sort_values('Time')
            if not s_para_10.empty:
                plt.plot(s_para_10['Time'], s_para_10['Count_Para_10'], 
                         label='Parallel (10x10x10)', 
                         color='#2ca02c', linewidth=2.5, marker='^', markersize=5, linestyle='-.')
            
        # 优化图表样式
        plt.title(f'Species Evolution Comparison: {species}', fontsize=14, fontweight='bold')
        plt.xlabel('Simulation Time (s)', fontsize=12)
        plt.ylabel('Cluster Count', fontsize=12)
        plt.grid(True, linestyle='--', alpha=0.5)
        plt.legend(fontsize=11)
        
        # 调整刻度格式，防止科学计数法堆叠
        plt.ticklabel_format(style='sci', axis='x', scilimits=(-3, 4))
        
        # 保存图片
        safe_filename = sanitise_filename(species)
        output_path = os.path.join(OUTPUT_DIR, safe_filename)
        plt.tight_layout()
        plt.savefig(output_path, dpi=150)
        plt.close()
        
        print(f"    -> 已保存: {output_path}")

    print(f"\n✅ 全部完成！请进入文件夹 [{OUTPUT_DIR}] 查看分析图。")

if __name__ == "__main__":
    main()