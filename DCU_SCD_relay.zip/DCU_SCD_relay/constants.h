/**
 * Definition of constants in the code.
 * All definition are in CAP letters.
 */

// Universal constants:

#define PI 3.1415926
#define KB 8.617e-05       // [ev/K] Boltzmann's constant.
  
// Material properties:
#define DENSITY 6.3988e+22 // [atoms/cm^3] Atomic density for W.
#define ALATT 3.146e-08      // [cm] Lattice parameter for W.
#define R_IV  4.811E-8		// [cm] recombination reactor of I1+V1
#define DISLOCATION 7e+9   // [cm^-2] Dislocation density.
#define ODS_R 2.5e-07       // [cm] ODS-particle radius.    !!!<OFF>!!!
#define ODS_DENSITY 2.6e+17 // [cm^-3] ODS-particle density.!!!<OFF>!!!
#define GRAIN_SIZE 3e-4     // [cm] Typical grain size.     !!!<OFF>!!!
#define NU0I 1.50e+12       // [Hz] Attempt frequency of ITL
#define NU0V 6.46e+12       // [Hz] Attempt frequency of VCC
#define C_DENSITY 10        // [appm] C-atom density        !!!<OFF>!!!(probably)
#define GAMMA 1.0           // Fraction of surface emission.
#define TDE 60              // [eV] Threshold displacement energy for W.

// Run parameters:
// #define VOLUME 1.0e-16      // [cm^3] System volume.
// #define TOTAL_VOLUME 1.0e-16   // 定义总体积 (物理常数)
extern double local_volume;    // 声明本地体积变量
#define TEMPERATURE 811.0  // [K] System temperature.
#define CHANNELS 2          // Irradiation channels used (1:W, 2:He, 3:H,...).
#define EXP10 7.0           // Number of significant figures per key field.

// Running time pars:
#define PSTEPS     10000  // Print data every so many.
//#define TSTEPS  1000000000  // Run these many steps.
//#define TOTAL_TIME 4.8e+07  // [s] Total simulated time.
#define TOTAL_DPA      0.96  // [dpa] Total simulated dpas (DPA/rate)

// All rates 
#define PKA                 	// Irradiation type.
#define DPA_RATE 3.56e-07	// [dpa/s] Damage rate. <if PKA, only for cal other rates>
#define PKA_RATE        2e15	// [pka/s/cm^3] for W
//#define RE_RATE1   181.65606738	// [appm/dpa] Re transmutation rate 
//#define RE_RATE0   521.58147823	// rate= RE_RATE1 * dpa + RE_RATE0
#define RE_RATE1   0	// [appm/dpa] Re transmutation rate 
#define RE_RATE0   0	// rate= RE_RATE1 * dpa + RE_RATE0

#define RATIO_HE 0.0        // [appm/dpa] He-to-dpa ratio.  !!!<OFF>!!!
#define RATIO_H 0           //                              !!!<OFF>!!!

#define TRACK          // output Re contribution to "trackRE.out"

// Auxiliary definitions: 
/* #define RESTART            // Do restart. */
/* #define RATE_DUMP          // Dump rate spectrum every PSTEPS. */
/* #define DEBUG              // Check cascade damage. */

// ==========================================================
// >>> 跨界跳跃 (Diffusion Jump) 通道定义 >>>
// ==========================================================
#define JUMP_CHANNELS 6 // 三维空间有 6 个相邻面 (X-, X+, Y-, Y+, Z-, Z+)

// 核心改造：反应矩阵的前半部分数组长度
// 1(Sink 0阶) + LEVELS(发射 1阶) + 6(跳跃 1阶)
#define ZF_LENGTH (1 + LEVELS + JUMP_CHANNELS) 

// 暴露网格的物理边长供计算跳跃速率使用
extern double mesh_Lx;
extern double mesh_Ly;
extern double mesh_Lz;
extern double mesh_volume;