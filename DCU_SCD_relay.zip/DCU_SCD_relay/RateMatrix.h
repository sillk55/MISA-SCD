#pragma once

#include <hip/hip_runtime.h>
#include "constants.h"
#include <stdlib.h>
#include <time.h>
#include "types.h"

extern int64 i_step;

struct Material {
    double r1, r1e;
    int object_index;  
    int64 object_key;  
    double rates[ZF_LENGTH + MAX_SPECIES]; 
};

struct Reaction {
    int object_index;  
    int64 object_key;
    char status;
};

struct RateMatrix {
    struct Material lineHead[MAX_SPECIES]; 
    int lineLength;

    struct Reaction columnHead[ZF_LENGTH + MAX_SPECIES]; 
    int secondLength;

    int newMaterials[MAX_SPECIES]; 
    int newMaterialLength;
    int newMobiles[MAX_SPECIES];
    int newMobileLength;

    double damage[CHANNELS]; 
    double totalRate;        

    // >>> 核心修改：GPU 物理上下文自包含 <<<
    double m_volume;
    double l_volume;
    double Lx, Ly, Lz;
    double avol;
    double jumpd;
    double ss[2];
};

struct DiffusionResult {
    int64 key;         
    double Diffrate;   
    double totalrate;  
    double lifetime;   
    double diffLength; 
};

// 初始化函数 (现在需要传入局部网格环境参数)
struct RateMatrix *initialization(double m_vol, double l_vol, double lx, double ly, double lz);

// =========================================================
// >>> 全面升级：所有函数均支持 GPU/CPU 双端运行 <<<
// =========================================================
__host__ __device__ double computeDamages(struct RateMatrix *rateMatrix, double dpa);

__host__ __device__ void computeR1R1e(struct RateMatrix *rateMatrix, struct Material *material, struct object_t *objects_all);
__host__ __device__ double computeZeroReaction(struct RateMatrix *rateMatrix, const struct object_t *P_1);
__host__ __device__ double computeOneReaction(struct RateMatrix *rateMatrix, struct Material *material, int index, struct object_t *objects_all);
__host__ __device__ double computeJumpReaction(struct RateMatrix *rateMatrix, const struct object_t *P_1, int dir);
__host__ __device__ double computeTwoReaction(struct RateMatrix *rateMatrix, struct Material *material, const struct object_t *P_2, struct object_t *objects_all);

__host__ __device__ void removeSecondArrayColumn(struct RateMatrix *rateMatrix, int deleteIndex);
__host__ __device__ void calculateSecondColumnAndEnlargeIfNeed(struct RateMatrix *rateMatrix, struct object_t *objects_all);
__host__ __device__ struct Material *addLine(struct RateMatrix *rateMatrix, int newObjectIndex, struct object_t *objects_all); 
__host__ __device__ void computeLine(struct RateMatrix *rateMatrix, struct Material *material, char status, struct object_t *objects_all);

__host__ __device__ void addRemoveInRateMatrix(struct RateMatrix *rateMatrix, struct object_t *objects_all, int active_objects_count);
__host__ __device__ void deleteLine(struct RateMatrix *rateMatrix, int64 key, struct object_t *objects_all);
__host__ __device__ void computeSecondArrayColumn(struct RateMatrix *rateMatrix, int secondIndex, struct object_t *objects_all);
__host__ __device__ void update(struct RateMatrix *rateMatrix, int64 key, struct object_t *objects_all);

// 核心修改：通过外部传入随机数 xi2，彻底剥离对 CPU drand48() 的依赖
__host__ __device__ void selectReaction(struct RateMatrix *rateMatrix, int *lIndex, int *cIndex, double xi2);
__host__ __device__ void calibrateTotalRate(struct RateMatrix *rateMatrix);

void sync_matrix_indices(struct RateMatrix *rateMatrix);
void update_matrix_object_index(struct RateMatrix *rateMatrix, int64 key, int new_index);

// =================================================================
// >>> 阶段 4.3：终极 Mega-Kernel (主循环全量 GPU 化) 声明 <<<
// =================================================================
__global__ void kmc_evolution_kernel(
    struct mesh_t *local_meshes,
    int *mesh_ids,
    int num_meshes,
    double global_time,
    double tau_kmc,
    unsigned int base_seed,
    double *d_PKA_energy,
    double *d_p_of_PKA_energy,
    int *d_num_of_Cas_per_energy,
    struct cascade_def **d_casdef
);

__global__ void calc_max_rate_kernel(struct mesh_t *local_meshes, int num_total_meshes, double global_time, double *d_max_rates);