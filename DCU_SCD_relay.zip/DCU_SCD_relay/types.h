#pragma once

#include <hip/hip_runtime.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>

#define MAX_SPECIES 1000

#define RETURN_SUCCESS EXIT_SUCCESS
#define RETURN_FAILURE EXIT_FAILURE
#define LEVELS 2 

typedef long long int int64;

struct object_t {
    int64          key;                
    int            attributes[LEVELS]; 
    int            number;             
    unsigned int   dimensionality;     
    double         diff;               
    double         binding[LEVELS];    
};

struct cascade_def {
    double cascade_energy;
    int    cascade_id;
    int    nidef;
    int* isize;
    int* inum;
    int    nvdef;
    int* vsize;
    int* vnum;
};

struct mesh_t {
    int local_id;                
    int is_shell; 
    double volume;               
    double bounds[6];            
    int is_ghost;           
    int neighbor_ids[6];    
    int owner_rank;         

    // >>> 新增：GPU 硬件级显存并发锁 <<<
    int lock; 

    struct object_t objects_all[MAX_SPECIES]; 
    int active_objects_count;                 
    
    struct RateMatrix *matrix;       
};

struct sector_t {
    int sector_id;               
    int num_meshes;              
    int *mesh_ids;               
};

extern struct mesh_t *local_meshes; 
extern struct sector_t local_sectors[8];
extern int num_local_meshes;

struct RateMatrix;

extern struct RateMatrix* rateMatrix;
extern struct mesh_t *current_mesh;

// =========================================================
// >>> 核心数学与物理公式 (内联设备端) <<<
// =========================================================

#ifndef PI
#define PI 3.1415926
#endif

#include "constants.h"

__host__ __device__ inline int signof(int64 a) { return (a < 0) ? -1 : 1; }
__host__ __device__ inline double zero(int a) { return (abs(a) > 1) ? 1.0 : 0.0; }

__host__ __device__ inline double dimension_term(double rab, const struct object_t *a, const struct object_t *b, double m_volume, double l_volume) {
  double term;
  int dimsum = a->dimensionality + b->dimensionality; 
  double alpha_a = -log(PI * PI * pow(rab, 3.0) / l_volume / a->number);
  double alpha_b = -log(PI * PI * pow(rab, 3.0) / l_volume / b->number);

  switch (dimsum) {
  case 6: term = a->diff + b->diff; break;
  case 4: 
    if (a->dimensionality == 1 && b->dimensionality == 3) term = a->diff * (b->number / m_volume) * (2.0 * PI * pow(rab, 3.0)) + b->diff;
    else term = b->diff * (b->number / m_volume) * (2.0 * PI * pow(rab, 3.0)) + a->diff;
    break;
  case 2: term = a->diff / alpha_b + b->diff / alpha_a; break;
  default: term = a->diff + b->diff; break;
  }
  return term;
}

__host__ __device__ inline void get_attributes(int64 key, int attr_out[LEVELS]) {
  int i;
  int64 okey = (int64)(llabs(key));

  for (i = 0; i < LEVELS; i++) {
    attr_out[i] = (double)okey / pow(10.0, (double)EXP10 * (LEVELS - 1 - i));
    if (attr_out[i] > 0.8 * pow(10.0, (double)EXP10)) { 
      printf("(get_attributes) Error: overflow. %lld %d %d %f\n", key, i, attr_out[i], EXP10);
    } 
    okey -= ((int64)attr_out[i]) * ((int64)pow(10.0, (double)EXP10 * (LEVELS - 1 - i)));
  }
  attr_out[0] *= signof(key);
}

__host__ __device__ inline double compute_diff_coeff(const int attr[LEVELS]) {
  const double jumpd1 = sqrt(3.0) * ALATT / 2.0; 
  const double jumpd2 = ALATT;                   
  double prefactor = 0, energy_m = 0;
  double diff = 0;
  int check_all = 0, check_Re = 0;
  int i;

  for (i = 1; i < LEVELS; i++) {
    check_all |= attr[i];
    if (i >= 2) check_Re |= attr[i];
  }

  if (!check_all) {
    if (attr[0] > 0) { 
      if (labs(attr[0]) == 1) { prefactor = 0.5 * jumpd1 * jumpd1 * 1.43E12; energy_m = 0.04; }
      else if (labs(attr[0]) > 1) { prefactor = 0.5 * 1.43E12 * jumpd1 * jumpd1 * pow(fabs((double)attr[0]), -0.365); energy_m = 0.04; }
    } else if (attr[0] < 0) { 
      if (labs(attr[0]) == 1) { prefactor = 1.0 / 6 * 6E12 * jumpd1 * jumpd1; energy_m = 1.66; }
      else if (labs(attr[0]) == 2) { energy_m = 1.66; prefactor = 1.0 / 6 * 6E12 * jumpd1 * jumpd1; }
      else if (labs(attr[0]) == 3) { energy_m = 0.89; prefactor = 1.0 / 6 * 6E12 * jumpd1 * jumpd1; }
      else if (labs(attr[0]) == 4) { energy_m = 1.55; prefactor = 1.0 / 6 * 6E12 * jumpd1 * jumpd1; }
      else { prefactor = 0; }
    }
  } else if (!check_Re) {
    if (attr[0] > 0) { 
      if (attr[0] == 1 && attr[1] == 1) { prefactor = 0.5 * 1.43E12 * jumpd2 * jumpd2; energy_m = 0.11; }
      else prefactor = 0.0; 
    } else if (attr[0] < 0) {
      if (labs(attr[0]) <= 2 && attr[1] <= 6) { prefactor = 1.0 / 6 * 6E12 * jumpd2 * jumpd2; energy_m = 1.66; }
      else if (labs(attr[0]) == 3 && attr[1] <= 6) { prefactor = 1.0 / 6 * 6E12 * jumpd2 * jumpd2; energy_m = 0.89; }
      else { prefactor = 0.0; }
    } else {
      if (attr[1] == 1) { prefactor = 5.13E13 * 1.0 / 6 * jumpd1 * jumpd1; energy_m = 4.79; }
      else prefactor = 0.0; 
    }
  }

  diff = prefactor * exp(-energy_m / KB / TEMPERATURE);
  return diff;
}

__host__ __device__ inline void compute_bind_term(const int attr[LEVELS], double bind_out[LEVELS]) {
  double energy_d[LEVELS] = {0.0};
  double energy_b = 0.0;
  double attfreq = 1.0;
  int check_all = 0, check_Re = 0;
  int i;

  for (i = 0; i < LEVELS; i++) {
    bind_out[i] = 0;
    if (i >= 1) check_all |= attr[i];
    if (i >= 2) check_Re |= attr[i];
  }

  if (!check_all) {
    if (attr[0] > 0) { 
      if (labs(attr[0]) == 1) { attfreq = 0.0; }
      else if (labs(attr[0]) == 2) { energy_b = 2.45; }
      else if (labs(attr[0]) == 3) { energy_b = 3.65; }
      else if (labs(attr[0]) == 4) { energy_b = 4.60; }
      else if (labs(attr[0]) == 5) { energy_b = 4.60; }
      else if (labs(attr[0]) == 6) { energy_b = 5.13; }
      else if (labs(attr[0]) > 6) {
        double var = sqrt((double)attr[0]) * log((double)attr[0]) - sqrt((double)attr[0] - 1.0) * log((double)attr[0] - 1.0);
        energy_b = 10.21 - 35.96 * (sqrt((double)attr[0]) - sqrt((double)attr[0] - 1.0)) + 3.06 * var;
      }
    } else if (attr[0] < 0) { 
      if (labs(attr[0]) == 1) { attfreq = 0.0; }
      else if (labs(attr[0]) == 2) { energy_b = -0.12; }
      else if (labs(attr[0]) == 3) { energy_b = -0.01; }
      else if (labs(attr[0]) == 4) { energy_b = 0.64; }
      else if (labs(attr[0]) == 5) { energy_b = 0.52; }
      else if (labs(attr[0]) == 6) { energy_b = 1.21; }
      else if (labs(attr[0]) == 7) { energy_b = 0.77; }
      else if (labs(attr[0]) == 8) { energy_b = 0.96; }
      else if (labs(attr[0]) == 9) { energy_b = 0.85; }
      else if (labs(attr[0]) == 10) { energy_b = 1.56; }
      else if (labs(attr[0]) == 11) { energy_b = 0.96; }
      else if (labs(attr[0]) == 12) { energy_b = 1.56; }
      else if (labs(attr[0]) > 12) 
        energy_b = 3.33 - (6.86 - 3.33) * (pow(fabs((double)attr[0]), 0.6666667) - pow((fabs((double)attr[0]) - 1.0), 0.6666667)) / 0.5874;
    }

    energy_d[0] = energy_b;                                   
    bind_out[0] = attfreq * exp(-energy_d[0] / KB / TEMPERATURE); 
  } else if (!check_Re) {
    double nv = fabs((double)attr[0]); 
    double nr = fabs((double)attr[1]);

    if (attr[0] < 0) { 
      if (labs(attr[0]) == 1 && labs(attr[1]) == 1) { energy_d[0] = 0.2; energy_d[1] = energy_d[0]; }
      else { 
        if (labs(attr[0]) <= 3 && attr[1] <= 8) {
          energy_d[0] = 0.27285227 * pow((double)nv, -0.30702658) * pow((double)nr, 0.59015479);
          energy_d[1] = 0.079 + 0.154 * nv / nr;
        } else { attfreq = 0; }
      }
      bind_out[0] = attfreq * exp(-energy_d[0] / KB / TEMPERATURE); 
      bind_out[1] = attfreq * exp(-energy_d[1] / KB / TEMPERATURE);
    } else if (attr[0] > 0) { 
      if (labs(attr[0]) == 1 && labs(attr[1]) == 1) { energy_d[0] = 0.78; energy_d[1] = 0.78; } 
      else if (labs(attr[0]) == 1 && labs(attr[1]) == 2) { energy_d[0] = 1.75; energy_d[1] = 0.95; }
      else if (labs(attr[0]) == 1 && labs(attr[1]) == 3) { energy_d[0] = 2.19; energy_d[1] = 0.44; }
      else if (labs(attr[0]) == 1 && labs(attr[1]) == 4) { energy_d[0] = 2.63; energy_d[1] = 0.44; }
      else if (labs(attr[0]) == 1 && labs(attr[1]) == 5) { energy_d[0] = 3.06; energy_d[1] = 0.42; }
      else if (labs(attr[0]) == 1 && labs(attr[1]) == 6) { energy_d[0] = 3.52; energy_d[1] = 0.46; }
      else if (labs(attr[0]) == 1 && abs(attr[1]) == 7) { energy_d[0] = 2.261 + 0.1168; energy_d[1] = 0.34; }
      else if (labs(attr[0]) == 1 && labs(attr[1]) > 7) { 
        if (attr[1] <= 11) energy_d[0] = 2.261 + 0.1168;
        else energy_d[0] = 10;
        double var1 = 1.21 * sqrt((double)attr[1]) * exp(-0.74 * sqrt((double)attr[1])) + 0.24;
        energy_d[1] = var1;
      }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 1) { energy_d[0] = 2.48; energy_d[1] = 0.84; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 2) { energy_d[0] = 2.36; energy_d[1] = 0.69; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 3) { energy_d[0] = 2.59; energy_d[1] = 0.62; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 4) { energy_d[0] = 2.82; energy_d[1] = 0.57; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 5) { energy_d[0] = 2.89; energy_d[1] = 0.54; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 6) { energy_d[0] = 2.98; energy_d[1] = 0.49; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) == 7) { energy_d[0] = 2.261 + 0.1168 * 2; energy_d[1] = 0.49; }
      else if (labs(attr[0]) == 2 && labs(attr[1]) > 7) { 
        if (attr[1] <= 11) energy_d[0] = 2.261 + 0.1168 * 2;
        else energy_d[0] = 10;
        double var1 = 1.21 * sqrt((double)attr[1]) * exp(-0.74 * sqrt((double)attr[1])) + 0.24;
        double var2 = pow(2.0, -0.70 * exp(-attr[1] / 1.1) - 0.16);
        energy_d[1] = var1 * var2;
      }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 1) { energy_d[0] = 3.61; energy_d[1] = 0.82; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 2) { energy_d[0] = 3.56; energy_d[1] = 0.71; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 3) { energy_d[0] = 3.65; energy_d[1] = 0.65; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 4) { energy_d[0] = 3.60; energy_d[1] = 0.61; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 5) { energy_d[0] = 3.74; energy_d[1] = 0.56; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 6) { energy_d[0] = 3.77; energy_d[1] = 0.55; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) == 7) { energy_d[0] = 3.56 + 0.0389 * 3; energy_d[1] = 0.55; }
      else if (labs(attr[0]) == 3 && labs(attr[1]) > 7) { 
        if (attr[1] <= 11) energy_d[0] = 3.56 + 0.0389 * 3;
        else energy_d[0] = 10;
        double var1 = 1.21 * sqrt((double)attr[1]) * exp(-0.74 * sqrt((double)attr[1])) + 0.24;
        double var2 = pow(3.0, -0.70 * exp(-attr[1] / 1.1) - 0.16);
        energy_d[1] = var1 * var2;
      }
      else if (labs(attr[0]) > 3) {
        energy_d[0] = 10;
        double var1 = 1.21 * sqrt((double)attr[1]) * exp(-0.74 * sqrt((double)attr[1])) + 0.24;
        double var2 = pow((double)attr[0], -0.70 * exp(-attr[1] / 1.1) - 0.16);
        energy_d[1] = var1 * var2;
      }

      bind_out[0] = attfreq * exp(-energy_d[0] / KB / TEMPERATURE);
      bind_out[1] = attfreq * exp(-energy_d[1] / KB / TEMPERATURE);
    } else if (attr[0] == 0) { 
      energy_d[1] = -0.0258 + 4.736e-6 * nr;
      bind_out[1] = attfreq * exp(-energy_d[1] / KB / TEMPERATURE);
    }
  }
}

__host__ __device__ inline void compute_sinks(double *s) {
  double Zdv = 1.0, Zdi = 1.15;
  double Zodsv = 0.0, Zodsi = 0.0;
  double Zgbv = 0.0, Zgbi = 0.0; 
  double Sd = DISLOCATION;
  double Sods = 4 * PI * ODS_R * ODS_DENSITY;
  double Sgbv = 6 * sqrt(Zdv * Sd + Zodsv * Sods) / GRAIN_SIZE;
  double Sgbi = 6 * sqrt(Zdi * Sd + Zodsi * Sods) / GRAIN_SIZE;

  s[0] = Zdv * Sd + Zgbv * Sgbv + Zodsv * Sods;
  s[1] = Zdi * Sd + Zgbi * Sgbi + Zodsi * Sods;
}

// =========================================================
// >>> 阶段 4.2：引入 GPU 伪随机数 PRNG 与 原子自旋锁 (Mutex) <<<
// =========================================================
__host__ __device__ inline double lcg_rand(unsigned int *seed) {
    *seed = (*seed * 1103515245 + 12345) & 0x7FFFFFFF;
    return (double)(*seed) / 2147483648.0;
}

__device__ inline void lock_mesh(int *mutex) {
    while (atomicCAS(mutex, 0, 1) != 0) {}
}

__device__ inline void unlock_mesh(int *mutex) {
    atomicExch(mutex, 0);
}

// 原版 CPU 声明保持不变
extern void process_event(struct object_t *my_object, int64 k2, int n2, double adv_time);
extern void get_insertion(const int channel);

extern struct object_t* add_object_hash(int64         new_object_id,
                                        const int     new_object_attributes[LEVELS],
                                        int           new_object_number,
                                        unsigned int  new_object_dimensionality,
                                        double        new_object_diff,
                                        const double  new_object_binding[LEVELS]);

extern struct object_t *find_object_hash(int64 object_id);
extern void delete_object_hash(struct object_t *obj_to_delete);
extern int key_sort(const void *a, const void *b);
extern void sort_objects(void);

// 声明新增的纯 GPU 版引擎
__host__ __device__ void insert_single_particle(int64 e_key, int number, struct mesh_t *mesh);
__host__ __device__ void process_event_gpu(struct object_t *my_object, int64 k2, int n2, struct mesh_t *mesh);
__host__ __device__ void get_insertion_gpu(int channel, struct mesh_t *mesh, unsigned int *seed, double *d_PKA_energy, double *d_p_of_PKA_energy, int *d_num_of_Cas_per_energy, struct cascade_def **d_casdef);